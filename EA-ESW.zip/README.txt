EA-ESW

EA-ESW(Exponent Aerospace-Extreme Sky Walker)为指数航天Exponent Aerospace研发的总冲1000Ns+级50mm内径55mm外径的制式可复用金属发动机

EA-ESW适用于各类APCP推进剂
由 外壳.step,喷管.step,堵头.step 组成
使用EA-ESW时,应当使用两段150mm长的APCP的Finocly药柱,具体规格见压缩包内部的 规格.png,隔热层应当使用外径50mm厚2mm的PVC或PPR或酚醛或环氧管材。两段药柱之间,药柱与喷管堵头之间都应当放入外径50mm线径2.5mm的O型氟胶密封圈,固定方式是两端各卡入一个卡簧，规格为50mm内卡。

所有EA-ESW系列的发动机外壳必须使用7075-T6铝合金制造,喷管堵头必须使用耐高温耐烧蚀材料(如酚醛,45#钢,304不锈钢等)

整个发动机的所有加工了密封槽的部分都要安装全新的未老化的外径50mm线径2.5mm的O型密封圈

©2025 指数航天 版权所有

有技术性问题可发邮件询问:
电子邮箱地址2772194090@qq.com

最新版图纸链接:
https://zzcjas.github.io/EA-ESW.zip

免责声明

指数航天（Exponent Aerospace）提供的EA-ESW发动机设计文件仅供教育、研究、学术参考及加工之目的。使用者必须具备相应的专业知识和技能，并完全理解固体火箭发动机实验所固有的极高风险，包括但不限于导致财产损失、信誉损失、人身伤害甚至死亡。

禁止填装除以上提到的任何其他数据未知或燃速过高的推进剂,禁止填装密度过小或工艺不达标的推进剂(如粉压燃料)

使用者自愿选择下载、使用或修改此设计文件，并须对由此产生的一切后果承担全部责任。设计者、版权所有者及文件提供者对任何直接、间接、特殊或后果性的损失或损害概不负责，无论其成因如何。

严禁将此设计用于任何非法、危险或商业用途。任何基于此设计的制造、测试或操作行为均被视为使用者自行承担风险的独立决定。继续使用即表示您已阅读、理解并无条件同意接受本免责声明的全部条款。

EA-ESW

EA-ESW (Exponent Aerospace - Extreme Sky Walker) is a standard reusable metal engine developed by Exponent Aerospace, with a total impulse of 1000 Ns+, an inner diameter of 50 mm, and an outer diameter of 55 mm.

The EA-ESW is compatible with various APCP propellants.
It consists of the following components:

Casing.step

Nozzle.step

End Cap.step

When using the EA-ESW, two 150 mm long Finocyl grain APCP propellant segments must be used. For specific specifications, refer to the "Specifications.png" file inside the compressed package. The insulation layer shall be made of PVC, PPR, phenolic, or epoxy tubing with an outer diameter of 50 mm and a wall thickness of 2 mm. Between the two propellant segments, as well as between the propellant and the nozzle/end cap, O-ring fluoroelastomer seals with an outer diameter of 50 mm and a cross-section diameter of 2.5 mm must be installed. The method of fixation involves securing a circlip at each end, with a specification of 50 mm internal circlips.

All engine casings in the EA32 series must be manufactured from 7075-T6 aluminum alloy. Nozzles and end caps must be made of high-temperature-resistant, ablation-resistant materials (such as phenolic resin, 45# steel, 304 stainless steel, etc.).

All machined sealing grooves in the engine must be equipped with new, non-aged O-ring seals with an outer diameter of 50 mm and a cross-section diameter of 2.5 mm.

© 2025 Exponent Aerospace. All rights reserved.

For technical inquiries, please contact:
Email: 2772194090@qq.com

Link to the latest version of the drawings:
https://zzcjas.github.io/EA-ESW.zip

Disclaimer

The EA-ESW engine design documents provided by Exponent Aerospace are intended solely for educational, research, academic reference, and manufacturing purposes. Users must possess the relevant professional knowledge and skills and fully understand the extremely high risks inherent in solid rocket engine experiments, including but not limited to property damage, loss of reputation, personal injury, or even death.

It is prohibited to load any propellant other than those mentioned above with unknown properties or excessively high burn rates. The use of propellants with insufficient density or substandard manufacturing processes (such as powder-pressed fuels) is strictly forbidden.

Users voluntarily choose to download, use, or modify these design documents and assume full responsibility for all consequences arising therefrom. The designers, copyright owners, and document providers shall not be held liable for any direct, indirect, special, or consequential losses or damages, regardless of their cause.

The use of this design for any illegal, hazardous, or commercial purposes is strictly prohibited. Any manufacturing, testing, or operational activities based on this design are considered independent decisions made at the user’s own risk. By proceeding with use, you acknowledge that you have read, understood, and unconditionally agreed to all terms of this disclaimer.