package net.zzcjas.nuclearindustry.util;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.syncher.EntityDataAccessor;
import java.lang.reflect.Field;

public class HealthOverrideHelper {
    private static final EntityDataAccessor<Float> DATA_HEALTH_ID;

    static {
        try {
            // 反射获取 LivingEntity 中的 DATA_HEALTH_ID 静态字段
            Field field = LivingEntity.class.getDeclaredField("DATA_HEALTH_ID");
            field.setAccessible(true);
            DATA_HEALTH_ID = (EntityDataAccessor<Float>) field.get(null);
        } catch (Exception e) {
            throw new RuntimeException("Failed to get DATA_HEALTH_ID", e);
        }
    }

    /**
     * 直接修改 EntityData 中的血量值，绕过所有 setHealth 拦截
     */
    public static void forceSetHealth(LivingEntity entity, float health) {
        entity.getEntityData().set(DATA_HEALTH_ID, health);
    }
}