package net.zzcjas.nuclearindustry.item;

import net.zzcjas.nuclearindustry.procedures.SuperPowerProcedure;
import net.zzcjas.nuclearindustry.procedures.NoooooProcedure;
import net.zzcjas.nuclearindustry.procedures.MatterSmashingProcedure;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;

import java.util.List;

import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;

public class MatterSmasherItem extends Item {
    public MatterSmasherItem() {
        super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
    }

    /**
     * 重写 getName 方法，使物品名称显示为流动彩虹渐变效果
     */
    @Override
    public Component getName(ItemStack stack) {
        String baseName = super.getName(stack).getString();
        return createRainbowComponent(baseName);
    }

    @Override
    public int getEnchantmentValue() {
        return 30;
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot equipmentSlot) {
        if (equipmentSlot == EquipmentSlot.MAINHAND) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.putAll(super.getDefaultAttributeModifiers(equipmentSlot));
            builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Item modifier", 1209d, AttributeModifier.Operation.ADDITION));
            builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Item modifier", -0.0, AttributeModifier.Operation.ADDITION));
            return builder.build();
        }
        return super.getDefaultAttributeModifiers(equipmentSlot);
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public boolean isFoil(ItemStack itemstack) {
        return true;
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
        super.appendHoverText(itemstack, level, list, flag);
        
        // 所有描述行均采用彩虹渐变
        list.add(createRainbowComponent(
                Component.translatable("tooltip.nuclear_industry.matter_smasher.line1").getString()));
        list.add(createRainbowComponent(
                Component.translatable("tooltip.nuclear_industry.matter_smasher.line2").getString()));
        list.add(createRainbowComponent(
                Component.translatable("tooltip.nuclear_industry.matter_smasher.line3").getString()));
        list.add(createRainbowComponent(
                Component.translatable("tooltip.nuclear_industry.matter_smasher.line4").getString()));
        
        list.add(Component.empty());
        
        // 功能介绍行也采用彩虹渐变
        list.add(createRainbowComponent(
                Component.translatable("tooltip.nuclear_industry.matter_smasher.godkill").getString()));
        list.add(createRainbowComponent(
                Component.translatable("tooltip.nuclear_industry.matter_smasher.aoe").getString()));
        list.add(createRainbowComponent(
                Component.translatable("tooltip.nuclear_industry.matter_smasher.defense").getString()));
    }

    /**
     * 生成动态彩虹渐变文本组件
     * @param text 原始文本
     * @return 带渐变颜色的 MutableComponent
     */
    private Component createRainbowComponent(String text) {
        MutableComponent component = Component.empty();
        int length = text.length();
        // 调整除数控制流动速度（数值越小流动越快）
        long timeOffset = System.currentTimeMillis() / 5;
        for (int i = 0; i < length; i++) {
            char c = text.charAt(i);
            // 色相步长影响颜色跨度
            int hue = (int) ((timeOffset + i * 30) % 360);
            int rgb = java.awt.Color.HSBtoRGB(hue / 360f, 1.0f, 1.0f);
            component.append(Component.literal(String.valueOf(c))
                    .withStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb))));
        }
        return component;
    }

    @Override
    public boolean onLeftClickEntity(ItemStack stack, Player player, Entity entity) {
        MatterSmashingProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
        return true;
    }

    @Override
    public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(itemstack, world, entity, slot, selected);
        SuperPowerProcedure.execute(entity);
    }

    @Override
    public boolean onDroppedByPlayer(ItemStack itemstack, Player entity) {
        NoooooProcedure.execute(entity);
        return true;
    }
}