
package net.zzcjas.nuclearindustry.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class WaterUnitItem extends Item {
	public WaterUnitItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}
}
