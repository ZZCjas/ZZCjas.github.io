package net.zzcjas.nuclearindustry.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModItems;

public class IItemHandlerHelper {

    private static Item matterSmasherItem = null;

    private static Item getMatterSmasherItem() {
        if (matterSmasherItem == null) {
            matterSmasherItem = NuclearIndustryModItems.MATTER_SMASHER.get();
        }
        return matterSmasherItem;
    }

    // 原有方法：检查主手、副手、玩家背包（用于免疫伤害）
    public static boolean hasMatterSmasher(Entity entity) {
        if (entity == null || !(entity instanceof LivingEntity living)) {
            return false;
        }

        // 防御性检查
        try {
            living.getMainHandItem();
        } catch (NullPointerException e) {
            return false;
        }

        Item smasher = getMatterSmasherItem();
        if (smasher == null) return false;

        ItemStack main = living.getMainHandItem();
        if (!main.isEmpty() && main.is(smasher)) return true;

        ItemStack off = living.getOffhandItem();
        if (!off.isEmpty() && off.is(smasher)) return true;

        if (living instanceof Player player) {
            try {
                for (ItemStack stack : player.getInventory().items) {
                    if (!stack.isEmpty() && stack.is(smasher)) return true;
                }
            } catch (NullPointerException e) {
                return false;
            }
        }
        return false;
    }

    // 新方法：只检查主手（用于攻击者强制秒杀）
    public static boolean hasMatterSmasherInMainHand(Entity entity) {
        if (entity == null || !(entity instanceof LivingEntity living)) {
            return false;
        }
        try {
            living.getMainHandItem();
        } catch (NullPointerException e) {
            return false;
        }
        Item smasher = getMatterSmasherItem();
        if (smasher == null) return false;
        ItemStack main = living.getMainHandItem();
        return !main.isEmpty() && main.is(smasher);
    }
}