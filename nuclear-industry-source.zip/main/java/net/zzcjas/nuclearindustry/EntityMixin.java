package net.zzcjas.nuclearindustry.mixin;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.zzcjas.nuclearindustry.util.IItemHandlerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = Entity.class, priority = 0)
public abstract class EntityMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void onHurt(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;

        // 持有物质粉碎机（背包/主副手）→ 免疫所有伤害
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.info("[NuclearIndustry] Blocked damage for {} from source: {}", self.getName().getString(), source.getMsgId());
            cir.setReturnValue(false);
            return;
        }

        // 攻击者主手持有物质粉碎机 → 强制秒杀
        Entity attacker = source.getEntity();
        boolean isMatterSmasherAttack = IItemHandlerHelper.hasMatterSmasherInMainHand(attacker);

        if (isMatterSmasherAttack && self instanceof LivingEntity livingTarget) {
            LOGGER.info("[NuclearIndustry] Instantly killed {} with Matter Smasher", livingTarget.getName().getString());
            livingTarget.setHealth(0.0F);
            livingTarget.die(source);
            cir.setReturnValue(true);
        }
    }
}