package net.zzcjas.nuclearindustry.mixin;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.zzcjas.nuclearindustry.util.IItemHandlerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 混入Entity类，修改伤害处理逻辑。
 * 注入点：{@link Entity#hurt(DamageSource, float)} 方法头部。
 */
@Mixin(value = Entity.class, priority = 0)
public abstract class EntityMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    // 自定义伤害类型：神圣秒杀
    private static final ResourceKey<DamageType> DIVINE_SLAYING_KEY =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("nuclear_industry", "divine_slaying"));

    /**
     * 在实体受伤前进行干预。
     * 1. 若持有物质粉碎机，免疫所有伤害。
     * 2. 若伤害类型为神圣秒杀，强制击杀目标。
     */
    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void onHurt(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;
        // 1. 持有物质粉碎机 → 免疫所有伤害
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.info("[NuclearIndustry] Blocked damage for {} from source: {}", self.getName().getString(), source.getMsgId());
            cir.setReturnValue(false);
            return;
        }
    }
}