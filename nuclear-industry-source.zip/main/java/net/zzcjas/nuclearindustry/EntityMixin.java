package net.zzcjas.nuclearindustry.mixin;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.zzcjas.nuclearindustry.util.IItemHandlerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 混入Entity类，修改伤害处理逻辑。
 * 注入点：{@link Entity#hurt(DamageSource, float)} 方法头部。
 */
@Mixin(value = Entity.class, priority = 0)
public abstract class EntityMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    // 自定义伤害类型：神圣秒杀
    private static final ResourceKey<DamageType> DIVINE_SLAYING_KEY =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("nuclear_industry", "divine_slaying"));

    /**
     * 在实体受伤前进行干预。
     * 1. 若持有物质粉碎机，免疫所有伤害。
     * 2. 若伤害类型为神圣秒杀，强制击杀目标。
     */
    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void onHurt(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;

        // 1. 持有物质粉碎机 → 免疫所有伤害
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.info("[NuclearIndustry] Blocked damage for {} from source: {}", self.getName().getString(), source.getMsgId());
            cir.setReturnValue(false);
            return;
        }

        // 2. 神圣秒杀伤害 → 强制秒杀
        if (source.is(DIVINE_SLAYING_KEY) && self instanceof LivingEntity livingTarget) {
            LOGGER.info("[NuclearIndustry] Instantly killed {} with divine slaying damage", livingTarget.getName().getString());

            // 将生命值置零，setHealth会自动同步EntityData
            livingTarget.setHealth(0.0F);
            // 播放死亡动画（客户端效果）
            livingTarget.level().broadcastEntityEvent(livingTarget, (byte) 3);

            // 若目标是玩家，显示死亡信息
            if (livingTarget instanceof Player player) {
                player.sendSystemMessage(player.getCombatTracker().getDeathMessage());
            }

            // 触发死亡逻辑
            livingTarget.die(source);
            cir.setReturnValue(true);
        }
    }
}