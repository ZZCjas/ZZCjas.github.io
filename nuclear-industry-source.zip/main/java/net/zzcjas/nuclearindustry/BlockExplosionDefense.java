package net.zzcjas.nuclearindustry.explosion.nuclear;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.server.level.ServerLevel;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModBlocks;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class BlockExplosionDefense {
    public static float getBlockDefenseValue(ServerLevel level, BlockPos pos, BlockState state) {
        if (state == null) return 0.0F;
        if (state.is(Blocks.BEDROCK)) {
            return 10_000.0F;
        }

        if (level != null && pos != null && state.getDestroySpeed(level, pos) < 0) {
            return 10_000.0F;
        }

        Block block = state.getBlock();
        if (block == Blocks.OBSIDIAN || block == Blocks.CRYING_OBSIDIAN) {
            return 250.0F;
        }

        if (block == Blocks.ANCIENT_DEBRIS) {
            return 400.0F;
        }
        if (block == NuclearIndustryModBlocks.REINFORCED_CONCRETE.get()) {
            return 400.0F;
        }
        if (block == Blocks.NETHERITE_BLOCK) {
            return 300.0F;
        }
		 float blastRes = state.getBlock().getExplosionResistance();

        if (blastRes <= 50.0F) {
            float t = blastRes / 50.0F;
            return 5.0F + t * 5.0F;
        }
        if (blastRes <= 250.0F) {
            return 25.0F;
        }
        if (blastRes <= 1000.0F) {
            return 50.0F;
        }
        return 100.0F;
    }
}