package net.zzcjas.nuclearindustry.explosion.nuclear;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.server.level.ServerLevel;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModBlocks;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class BlockExplosionDefense {

    /**
     * 获取方块的防御值（基于原版爆炸抗性）
     * - 基岩等不可破坏方块返回极大值 (10_000)
     * - 流体返回 0.2（确保被摧毁）
     * - 可替换/无碰撞方块返回 0.1（草、花等）
     * - 其他方块返回其爆炸抗性（已缩放至合理范围，可直接用于射线穿透计算）
     */
    public static float getBlockDefenseValue(ServerLevel level, BlockPos pos, BlockState state) {
        if (state == null) return 0.0F;

        // Бедрок - абсолютная защита
        if (state.is(Blocks.BEDROCK)) {
            return 10_000.0F;
        }

        if (level != null && pos != null && state.getDestroySpeed(level, pos) < 0) {
            return 10_000.0F;
        }

        Block block = state.getBlock();

        // === ЯВНО СУПЕР-ПРОЧНЫЕ БЛОКИ ===
        if (block == Blocks.OBSIDIAN || block == Blocks.CRYING_OBSIDIAN||block == NuclearIndustryModBlocks.REINFORCED_CONCRETE.get()) {
            return 250.0F;
        }

        if (block == Blocks.ANCIENT_DEBRIS) {
            return 400.0F;
        }

        if (block == Blocks.NETHERITE_BLOCK) {
            return 300.0F;
        }
		 float blastRes = state.getBlock().getExplosionResistance();

        // Диапазон 0-50: защита 5-10 (линейно)
        if (blastRes <= 50.0F) {
            float t = blastRes / 50.0F;
            return 5.0F + t * 5.0F;
        }

        // Диапазон 50-250: защита 25
        if (blastRes <= 250.0F) {
            return 25.0F;
        }

        // Диапазон 250-1000: защита 50
        if (blastRes <= 1000.0F) {
            return 50.0F;
        }

        // 1000+: защита 100
        return 100.0F;
    }
}