package net.zzcjas.nuclearindustry.util;

import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

public class ReflectionHelper {

    public static void zeroOutNumericFields(Object obj) {
        if (obj == null) return;
        zeroOutNumericFieldsRecursive(obj, new IdentityHashMap<>());
    }

    private static void zeroOutNumericFieldsRecursive(Object obj, Map<Object, Boolean> visited) {
        if (obj == null) return;
        if (visited.containsKey(obj)) return;
        visited.put(obj, true);

        Class<?> clazz = obj.getClass();

        // 处理 SynchedEntityData：遍历其内部 map，将所有数值类型的值清零
        if (obj instanceof SynchedEntityData data) {
            try {
                // 获取私有字段 itemsById（Map<Integer, DataItem<?>>）
                Field itemsByIdField = SynchedEntityData.class.getDeclaredField("itemsById");
                itemsByIdField.setAccessible(true);
                Map<Integer, Object> itemsById = (Map<Integer, Object>) itemsByIdField.get(data);
                if (itemsById != null) {
                    for (Object dataItem : itemsById.values()) {
                        // 每个 DataItem 中有一个 value 字段
                        Field valueField = dataItem.getClass().getDeclaredField("value");
                        valueField.setAccessible(true);
                        Object value = valueField.get(dataItem);
                        zeroOutNumericFieldsRecursive(value, visited);
                    }
                }
            } catch (Exception ignored) {}
        }

        // 处理 Collection
        if (obj instanceof Collection<?> collection) {
            for (Object element : collection) {
                zeroOutNumericFieldsRecursive(element, visited);
            }
            return;
        }

        // 处理 Map
        if (obj instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                zeroOutNumericFieldsRecursive(entry.getKey(), visited);
                zeroOutNumericFieldsRecursive(entry.getValue(), visited);
            }
            return;
        }

        // 处理数组
        if (obj instanceof Object[] array) {
            for (Object element : array) {
                zeroOutNumericFieldsRecursive(element, visited);
            }
            return;
        }

        // 处理 Minecraft NBT CompoundTag（简要处理）
        if (clazz.getName().equals("net.minecraft.nbt.CompoundTag")) {
            try {
                Method getAllKeys = clazz.getMethod("getAllKeys");
                Set<String> keys = (Set<String>) getAllKeys.invoke(obj);
                Method get = clazz.getMethod("get", String.class);
                for (String key : keys) {
                    Object tag = get.invoke(obj, key);
                    zeroOutNumericFieldsRecursive(tag, visited);
                }
            } catch (Exception ignored) {}
            return;
        }

        // 处理 NBT 数值标签
        if (clazz.getName().startsWith("net.minecraft.nbt.") && clazz.getName().endsWith("Tag")) {
            for (Field field : clazz.getDeclaredFields()) {
                Class<?> type = field.getType();
                if (type == int.class || type == float.class || type == double.class ||
                    type == long.class || type == short.class || type == byte.class) {
                    field.setAccessible(true);
                    if (Modifier.isFinal(field.getModifiers())) continue;
                    try {
                        field.set(obj, 0);
                    } catch (IllegalAccessException ignored) {}
                }
            }
            return;
        }

        // 递归处理所有字段
        Class<?> current = clazz;
        while (current != null && current != Object.class) {
            for (Field field : current.getDeclaredFields()) {
                int mod = field.getModifiers();
                if (Modifier.isStatic(mod)) continue;
                if (Modifier.isFinal(mod)) continue;
                field.setAccessible(true);
                Class<?> type = field.getType();
                try {
                    if (type == int.class) {
                        field.setInt(obj, 0);
                    } else if (type == float.class) {
                        field.setFloat(obj, 0.0f);
                    } else if (type == double.class) {
                        field.setDouble(obj, 0.0);
                    } else if (type == long.class) {
                        field.setLong(obj, 0L);
                    } else if (type == short.class) {
                        field.setShort(obj, (short) 0);
                    } else if (type == byte.class) {
                        field.setByte(obj, (byte) 0);
                    } else {
                        Object value = field.get(obj);
                        zeroOutNumericFieldsRecursive(value, visited);
                    }
                } catch (IllegalAccessException ignored) {}
            }
            current = current.getSuperclass();
        }
    }
}