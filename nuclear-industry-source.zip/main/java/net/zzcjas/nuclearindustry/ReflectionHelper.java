package net.zzcjas.nuclearindustry.util;

import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Map;

public class ReflectionHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");
    private static final sun.misc.Unsafe UNSAFE;

    static {
        sun.misc.Unsafe unsafe = null;
        try {
            Field field = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            unsafe = (sun.misc.Unsafe) field.get(null);
        } catch (Exception e) {
            LOGGER.error("Failed to obtain Unsafe instance", e);
        }
        UNSAFE = unsafe;
    }

    /**
     * 将所有数值字段设置为 0（默认）
     */
    public static void zeroOutNumericFields(Object obj) {
        setAllNumericFields(obj, 0);
    }

    /**
     * 将所有数值字段设置为指定的数值
     */
    public static void setAllNumericFields(Object obj, Number value) {
        if (obj == null || UNSAFE == null) return;
        setAllNumericFieldsRecursive(obj, value, new IdentityHashMap<>());
    }

    private static void setAllNumericFieldsRecursive(Object obj, Number value, Map<Object, Boolean> visited) {
        if (obj == null) return;

        // 新增：跳过玩家对象及其所有子字段
        if (obj instanceof Player) {
            LOGGER.debug("[ReflectionHelper] Skipping Player object: {}", obj);
            return;
        }

        if (obj instanceof String || obj instanceof Class || obj instanceof Thread || obj instanceof Module) {
            return;
        }
        if (visited.containsKey(obj)) return;
        visited.put(obj, true);

        Class<?> clazz = obj.getClass();

        // 处理 SynchedEntityData
        if (obj instanceof SynchedEntityData data) {
            try {
                Field itemsByIdField = SynchedEntityData.class.getDeclaredField("itemsById");
                itemsByIdField.setAccessible(true);
                Map<Integer, Object> itemsById = (Map<Integer, Object>) itemsByIdField.get(data);
                if (itemsById != null) {
                    for (Object dataItem : itemsById.values()) {
                        Field valueField = dataItem.getClass().getDeclaredField("value");
                        valueField.setAccessible(true);
                        Object innerValue = valueField.get(dataItem);
                        setAllNumericFieldsRecursive(innerValue, value, visited);
                    }
                }
            } catch (Exception e) {
                LOGGER.warn("Failed to process SynchedEntityData: {}", e.getMessage());
            }
        }

        // 处理 Collection
        if (obj instanceof Collection<?> collection) {
            for (Object element : collection) {
                setAllNumericFieldsRecursive(element, value, visited);
            }
            return;
        }

        // 处理 Map
        if (obj instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                setAllNumericFieldsRecursive(entry.getKey(), value, visited);
                setAllNumericFieldsRecursive(entry.getValue(), value, visited);
            }
            return;
        }

        // 处理数组
        if (obj instanceof Object[] array) {
            for (Object element : array) {
                setAllNumericFieldsRecursive(element, value, visited);
            }
            return;
        }

        // 跳过 CompoundTag 避免警告
        if (clazz.getName().equals("net.minecraft.nbt.CompoundTag")) {
            return;
        }

        // 处理 NBT 数值标签
        if (clazz.getName().startsWith("net.minecraft.nbt.") && clazz.getName().endsWith("Tag")) {
            for (Field field : clazz.getDeclaredFields()) {
                Class<?> type = field.getType();
                if (type == int.class || type == float.class || type == double.class ||
                    type == long.class || type == short.class || type == byte.class) {
                    if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) continue;
                    try {
                        long offset = UNSAFE.objectFieldOffset(field);
                        setNumericFieldUnsafe(obj, offset, type, value);
                    } catch (Exception e) {
                        LOGGER.warn("Failed to set NBT field {} using Unsafe: {}", field.getName(), e.getMessage());
                    }
                }
            }
            return;
        }

        // 递归处理所有字段
        Class<?> current = clazz;
        while (current != null && current != Object.class) {
            for (Field field : current.getDeclaredFields()) {
                int mod = field.getModifiers();
                if (Modifier.isStatic(mod) || Modifier.isFinal(mod)) continue;
                Class<?> type = field.getType();
                try {
                    if (type == int.class || type == float.class || type == double.class ||
                        type == long.class || type == short.class || type == byte.class) {
                        long offset = UNSAFE.objectFieldOffset(field);
                        setNumericFieldUnsafe(obj, offset, type, value);
                    } else {
                        // 非数值类型，递归处理其值
                        field.setAccessible(true);
                        Object child = field.get(obj);
                        if (child != null && !(child instanceof String) && !(child instanceof Class) && !(child instanceof Thread)) {
                            setAllNumericFieldsRecursive(child, value, visited);
                        }
                    }
                } catch (Exception e) {
                    LOGGER.warn("Failed to access field {}: {}", field.getName(), e.getMessage());
                }
            }
            current = current.getSuperclass();
        }
    }

    /**
     * 使用 Unsafe 将对象的指定偏移量处的数值字段设置为给定值
     */
    private static void setNumericFieldUnsafe(Object obj, long offset, Class<?> type, Number value) {
        if (UNSAFE == null) return;
        if (type == int.class) {
            UNSAFE.putInt(obj, offset, value.intValue());
        } else if (type == float.class) {
            UNSAFE.putFloat(obj, offset, value.floatValue());
        } else if (type == double.class) {
            UNSAFE.putDouble(obj, offset, value.doubleValue());
        } else if (type == long.class) {
            UNSAFE.putLong(obj, offset, value.longValue());
        } else if (type == short.class) {
            UNSAFE.putShort(obj, offset, value.shortValue());
        } else if (type == byte.class) {
            UNSAFE.putByte(obj, offset, value.byteValue());
        }
    }
}