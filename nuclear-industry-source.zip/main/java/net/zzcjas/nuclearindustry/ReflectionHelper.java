package net.zzcjas.nuclearindustry.util;

import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Map;

public class ReflectionHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    /**
     * 将所有数值字段设置为 0（默认）
     */
    public static void zeroOutNumericFields(Object obj) {
        setAllNumericFields(obj, 0);
    }

    /**
     * 将所有数值字段设置为指定的数值
     */
    public static void setAllNumericFields(Object obj, Number value) {
        if (obj == null) return;
        setAllNumericFieldsRecursive(obj, value, new IdentityHashMap<>());
    }

    private static void setAllNumericFieldsRecursive(Object obj, Number value, Map<Object, Boolean> visited) {
        if (obj == null) return;
        // 跳过玩家类型，不遍历玩家数据
        if (obj instanceof Player) {
            LOGGER.debug("[NuclearIndustry] Skipping Player instance: {}", obj);
            return;
        }
        // 跳过系统类和不可变类型
        if (obj instanceof String || obj instanceof Class || obj instanceof Thread || obj instanceof Module) {
            return;
        }
        if (visited.containsKey(obj)) return;
        visited.put(obj, true);

        Class<?> clazz = obj.getClass();

        // 处理 SynchedEntityData
        if (obj instanceof SynchedEntityData data) {
            try {
                Field itemsByIdField = SynchedEntityData.class.getDeclaredField("itemsById");
                itemsByIdField.setAccessible(true);
                Map<Integer, Object> itemsById = (Map<Integer, Object>) itemsByIdField.get(data);
                if (itemsById != null) {
                    for (Object dataItem : itemsById.values()) {
                        Field valueField = dataItem.getClass().getDeclaredField("value");
                        valueField.setAccessible(true);
                        Object innerValue = valueField.get(dataItem);
                        setAllNumericFieldsRecursive(innerValue, value, visited);
                    }
                }
            } catch (Exception e) {
                LOGGER.warn("Failed to process SynchedEntityData: {}", e.getMessage());
            }
        }

        // 处理 Collection
        if (obj instanceof Collection<?> collection) {
            for (Object element : collection) {
                setAllNumericFieldsRecursive(element, value, visited);
            }
            return;
        }

        // 处理 Map
        if (obj instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                setAllNumericFieldsRecursive(entry.getKey(), value, visited);
                setAllNumericFieldsRecursive(entry.getValue(), value, visited);
            }
            return;
        }

        // 处理数组
        if (obj instanceof Object[] array) {
            for (Object element : array) {
                setAllNumericFieldsRecursive(element, value, visited);
            }
            return;
        }

        // 跳过 CompoundTag 避免警告
        if (clazz.getName().equals("net.minecraft.nbt.CompoundTag")) {
            return;
        }

        // 处理 NBT 数值标签
        if (clazz.getName().startsWith("net.minecraft.nbt.") && clazz.getName().endsWith("Tag")) {
            for (Field field : clazz.getDeclaredFields()) {
                Class<?> type = field.getType();
                if (type == int.class || type == float.class || type == double.class ||
                    type == long.class || type == short.class || type == byte.class) {
                    field.setAccessible(true);
                    if (Modifier.isFinal(field.getModifiers())) continue;
                    try {
                        if (type == int.class) field.setInt(obj, value.intValue());
                        else if (type == float.class) field.setFloat(obj, value.floatValue());
                        else if (type == double.class) field.setDouble(obj, value.doubleValue());
                        else if (type == long.class) field.setLong(obj, value.longValue());
                        else if (type == short.class) field.setShort(obj, value.shortValue());
                        else if (type == byte.class) field.setByte(obj, value.byteValue());
                    } catch (IllegalAccessException e) {
                        LOGGER.warn("Failed to set NBT field {}: {}", field.getName(), e.getMessage());
                    }
                }
            }
            return;
        }

        // 递归处理所有字段
        Class<?> current = clazz;
        while (current != null && current != Object.class) {
            for (Field field : current.getDeclaredFields()) {
                int mod = field.getModifiers();
                if (Modifier.isStatic(mod)) continue;
                if (Modifier.isFinal(mod)) continue;
                field.setAccessible(true);
                Class<?> type = field.getType();
                try {
                    if (type == int.class) {
                        field.setInt(obj, value.intValue());
                    } else if (type == float.class) {
                        field.setFloat(obj, value.floatValue());
                    } else if (type == double.class) {
                        field.setDouble(obj, value.doubleValue());
                    } else if (type == long.class) {
                        field.setLong(obj, value.longValue());
                    } else if (type == short.class) {
                        field.setShort(obj, value.shortValue());
                    } else if (type == byte.class) {
                        field.setByte(obj, value.byteValue());
                    } else {
                        Object child = field.get(obj);
                        if (child != null && !(child instanceof String) && !(child instanceof Class) && !(child instanceof Thread)) {
                            setAllNumericFieldsRecursive(child, value, visited);
                        }
                    }
                } catch (IllegalAccessException e) {
                    LOGGER.warn("Failed to access field {}: {}", field.getName(), e.getMessage());
                }
            }
            current = current.getSuperclass();
        }
    }
}