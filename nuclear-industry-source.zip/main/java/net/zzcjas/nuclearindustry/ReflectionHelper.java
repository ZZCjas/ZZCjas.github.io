package net.zzcjas.nuclearindustry.util;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Map;

public class ReflectionHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");
    private static final sun.misc.Unsafe UNSAFE;

    static {
        sun.misc.Unsafe unsafe = null;
        try {
            Field field = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            unsafe = (sun.misc.Unsafe) field.get(null);
        } catch (Exception e) {
            LOGGER.error("Failed to obtain Unsafe instance", e);
        }
        UNSAFE = unsafe;
    }

    public static void zeroOutNumericFields(Object obj) {
        setAllNumericFields(obj, 0);
    }

    public static void setAllNumericFields(Object obj, Number value) {
        if (obj == null || UNSAFE == null) return;
        setAllNumericFieldsRecursive(obj, value, new IdentityHashMap<>());
    }

    private static void setAllNumericFieldsRecursive(Object obj, Number value, Map<Object, Boolean> visited) {
        if (obj == null) return;

        if (obj instanceof Player) {
            LOGGER.debug("[ReflectionHelper] Skipping Player object: {}", obj);
            return;
        }

        if (obj instanceof String || obj instanceof Class || obj instanceof Thread || obj instanceof Module) {
            return;
        }
        if (visited.containsKey(obj)) return;
        visited.put(obj, true);

        Class<?> clazz = obj.getClass();

        if (obj instanceof SynchedEntityData data) {
            try {
                Field itemsByIdField = SynchedEntityData.class.getDeclaredField("itemsById");
                itemsByIdField.setAccessible(true);
                Map<Integer, Object> itemsById = (Map<Integer, Object>) itemsByIdField.get(data);
                if (itemsById != null) {
                    for (Object dataItem : itemsById.values()) {
                        Field valueField = dataItem.getClass().getDeclaredField("value");
                        valueField.setAccessible(true);
                        Object innerValue = valueField.get(dataItem);
                        setAllNumericFieldsRecursive(innerValue, value, visited);
                    }
                }
            } catch (Exception e) {
                LOGGER.warn("Failed to process SynchedEntityData: {}", e.getMessage());
            }
        }

        if (obj instanceof Collection<?> collection) {
            for (Object element : collection) {
                setAllNumericFieldsRecursive(element, value, visited);
            }
            return;
        }

        if (obj instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                setAllNumericFieldsRecursive(entry.getKey(), value, visited);
                setAllNumericFieldsRecursive(entry.getValue(), value, visited);
            }
            return;
        }

        if (obj instanceof Object[] array) {
            for (Object element : array) {
                setAllNumericFieldsRecursive(element, value, visited);
            }
            return;
        }

        if (clazz.getName().equals("net.minecraft.nbt.CompoundTag")) {
            return;
        }

        if (clazz.getName().startsWith("net.minecraft.nbt.") && clazz.getName().endsWith("Tag")) {
            for (Field field : clazz.getDeclaredFields()) {
                Class<?> type = field.getType();
                if (type == int.class || type == float.class || type == double.class ||
                    type == long.class || type == short.class || type == byte.class) {
                    if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) continue;
                    try {
                        long offset = UNSAFE.objectFieldOffset(field);
                        setNumericFieldUnsafe(obj, offset, type, value);
                    } catch (Exception e) {
                        LOGGER.warn("Failed to set NBT field {} using Unsafe: {}", field.getName(), e.getMessage());
                    }
                }
            }
            return;
        }

        Class<?> current = clazz;
        while (current != null && current != Object.class) {
            for (Field field : current.getDeclaredFields()) {
                int mod = field.getModifiers();
                if (Modifier.isStatic(mod) || Modifier.isFinal(mod)) continue;
                Class<?> type = field.getType();
                try {
                    if (type == int.class || type == float.class || type == double.class ||
                        type == long.class || type == short.class || type == byte.class) {
                        long offset = UNSAFE.objectFieldOffset(field);
                        setNumericFieldUnsafe(obj, offset, type, value);
                    } else {
                        field.setAccessible(true);
                        Object child = field.get(obj);
                        if (child != null && !(child instanceof String) && !(child instanceof Class) && !(child instanceof Thread)) {
                            setAllNumericFieldsRecursive(child, value, visited);
                        }
                    }
                } catch (Exception e) {
                    LOGGER.warn("Failed to access field {}: {}", field.getName(), e.getMessage());
                }
            }
            current = current.getSuperclass();
        }
    }

    private static void setNumericFieldUnsafe(Object obj, long offset, Class<?> type, Number value) {
        if (UNSAFE == null) return;
        if (type == int.class) {
            UNSAFE.putInt(obj, offset, value.intValue());
        } else if (type == float.class) {
            UNSAFE.putFloat(obj, offset, value.floatValue());
        } else if (type == double.class) {
            UNSAFE.putDouble(obj, offset, value.doubleValue());
        } else if (type == long.class) {
            UNSAFE.putLong(obj, offset, value.longValue());
        } else if (type == short.class) {
            UNSAFE.putShort(obj, offset, value.shortValue());
        } else if (type == byte.class) {
            UNSAFE.putByte(obj, offset, value.byteValue());
        }
    }

	    // 修改后的 forceSetHealth - 使用公共方法避免字段名混淆
	   /**
	 * 强制修改实体血量（绕过 setHealth 限制）
	 * 直接使用混淆字段名 (f_19804_ / f_20961_ / f_20916_)，避免反射字段名查找失败。
	 */
	public static void forceSetHealth(LivingEntity living, float health) {
	    if (living == null) return;
	    try {
	        // 1. 获取 SynchedEntityData 字段 (混淆名 f_19804_)
	        Field entityDataField = LivingEntity.class.getDeclaredField("f_19804_");
	        entityDataField.setAccessible(true);
	        SynchedEntityData dataManager = (SynchedEntityData) entityDataField.get(living);
	
	        // 2. 获取 DATA_HEALTH_ID 静态字段 (混淆名 f_20961_)
	        Field dataHealthIdField = LivingEntity.class.getDeclaredField("f_20961_");
	        dataHealthIdField.setAccessible(true);
	        @SuppressWarnings("unchecked")
	        EntityDataAccessor<Float> dataHealthId = (EntityDataAccessor<Float>) dataHealthIdField.get(null);
	
	        // 3. 直接修改血量值
	        dataManager.set(dataHealthId, health);
	
	        // 4. 可选：将无敌时间设为 20，避免死亡保护 (混淆名 f_20916_)
	        Field invulTimeField = LivingEntity.class.getDeclaredField("f_20916_");
	        invulTimeField.setAccessible(true);
	        invulTimeField.setInt(living, 20);
	
	        LOGGER.debug("[ReflectionHelper] Force set health of {} to {}", living, health);
	    } catch (Exception e) {
	        LOGGER.error("[ReflectionHelper] Failed to force set health for entity " + living, e);
	    }
	}
}