
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

public class NuclearIndustryModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, NuclearIndustryMod.MODID);
	public static final RegistryObject<Potion> RAD_AWAY = REGISTRY.register("rad_away",
			() -> new Potion(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 7200, 0, false, false), new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 0, false, false)));
	public static final RegistryObject<Potion> ADVANCED_RAD_AWAY = REGISTRY.register("advanced_rad_away",
			() -> new Potion(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 10000, 1, false, false), new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 600, 0, false, false)));
	public static final RegistryObject<Potion> SUPER_RAD_AWAY = REGISTRY.register("super_rad_away", () -> new Potion(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 10000, 2, false, false),
			new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 1, false, false), new MobEffectInstance(MobEffects.REGENERATION, 100, 2, false, false)));
}
