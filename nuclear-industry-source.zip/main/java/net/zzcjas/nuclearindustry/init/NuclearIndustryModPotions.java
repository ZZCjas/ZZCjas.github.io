
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

public class NuclearIndustryModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, NuclearIndustryMod.MODID);
	public static final RegistryObject<Potion> RAD_AWAY = REGISTRY.register("rad_away", () -> new Potion(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 7200, 0, false, false)));
	public static final RegistryObject<Potion> ADVANCED_RAD_AWAY = REGISTRY.register("advanced_rad_away", () -> new Potion(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 10000, 1, false, false)));
	public static final RegistryObject<Potion> SUPER_RAD_AWAY = REGISTRY.register("super_rad_away", () -> new Potion(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 7200, 2, false, false)));
}
