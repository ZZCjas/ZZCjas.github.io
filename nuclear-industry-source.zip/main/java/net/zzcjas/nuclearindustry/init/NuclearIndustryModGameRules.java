
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class NuclearIndustryModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> ENABLE_NUCLEAR_EXPLOSION = GameRules.register("enableNuclearExplosion", GameRules.Category.MISC, GameRules.BooleanValue.create(true));
}
