
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.item.UraniumNuggetItem;
import net.zzcjas.nuclearindustry.item.UraniumIngotItem;
import net.zzcjas.nuclearindustry.item.LeadIngotItem;
import net.zzcjas.nuclearindustry.item.FissionCoreItem;
import net.zzcjas.nuclearindustry.item.EnrichedUraniumItem;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class NuclearIndustryModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NuclearIndustryMod.MODID);
	public static final RegistryObject<Item> NUKE = block(NuclearIndustryModBlocks.NUKE);
	public static final RegistryObject<Item> RADIOACTIVE_MELT = block(NuclearIndustryModBlocks.RADIOACTIVE_MELT);
	public static final RegistryObject<Item> BURNT_PLANK = block(NuclearIndustryModBlocks.BURNT_PLANK);
	public static final RegistryObject<Item> BURNT_WOOD = block(NuclearIndustryModBlocks.BURNT_WOOD);
	public static final RegistryObject<Item> RADIOACTIVE_DIRT = block(NuclearIndustryModBlocks.RADIOACTIVE_DIRT);
	public static final RegistryObject<Item> BURNT_GRASS = block(NuclearIndustryModBlocks.BURNT_GRASS);
	public static final RegistryObject<Item> URANIUM_INGOT = REGISTRY.register("uranium_ingot", () -> new UraniumIngotItem());
	public static final RegistryObject<Item> URANIUM_ORE = block(NuclearIndustryModBlocks.URANIUM_ORE);
	public static final RegistryObject<Item> URANIUM_BLOCK = block(NuclearIndustryModBlocks.URANIUM_BLOCK);
	public static final RegistryObject<Item> ENRICHED_URANIUM = REGISTRY.register("enriched_uranium", () -> new EnrichedUraniumItem());
	public static final RegistryObject<Item> FISSION_CORE = REGISTRY.register("fission_core", () -> new FissionCoreItem());
	public static final RegistryObject<Item> LEAD_INGOT = REGISTRY.register("lead_ingot", () -> new LeadIngotItem());
	public static final RegistryObject<Item> LEAD_ORE = block(NuclearIndustryModBlocks.LEAD_ORE);
	public static final RegistryObject<Item> LEAD_BLOCK = block(NuclearIndustryModBlocks.LEAD_BLOCK);
	public static final RegistryObject<Item> URANIUM_NUGGET = REGISTRY.register("uranium_nugget", () -> new UraniumNuggetItem());
	public static final RegistryObject<Item> REINFORCED_CONCRETE = block(NuclearIndustryModBlocks.REINFORCED_CONCRETE);
	public static final RegistryObject<Item> FALLOUT = block(NuclearIndustryModBlocks.FALLOUT);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
