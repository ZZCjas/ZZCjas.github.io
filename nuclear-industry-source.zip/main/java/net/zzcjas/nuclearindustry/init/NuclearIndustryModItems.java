
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.item.UraniumNuggetItem;
import net.zzcjas.nuclearindustry.item.UraniumIngotItem;
import net.zzcjas.nuclearindustry.item.UraniumDustItem;
import net.zzcjas.nuclearindustry.item.SteelPlateItem;
import net.zzcjas.nuclearindustry.item.SteelIngotItem;
import net.zzcjas.nuclearindustry.item.SteelDustItem;
import net.zzcjas.nuclearindustry.item.SmallPileOfEnrichedUraniumDustItem;
import net.zzcjas.nuclearindustry.item.NeutronReflectorItem;
import net.zzcjas.nuclearindustry.item.MotorItem;
import net.zzcjas.nuclearindustry.item.LeadIngotItem;
import net.zzcjas.nuclearindustry.item.LeadDustItem;
import net.zzcjas.nuclearindustry.item.IronPlateItem;
import net.zzcjas.nuclearindustry.item.IronDustItem;
import net.zzcjas.nuclearindustry.item.HammerItem;
import net.zzcjas.nuclearindustry.item.FissionCoreItem;
import net.zzcjas.nuclearindustry.item.EnrichedUraniumItem;
import net.zzcjas.nuclearindustry.item.EnrichedUraniumDustItem;
import net.zzcjas.nuclearindustry.item.AntiRadClothItem;
import net.zzcjas.nuclearindustry.item.AntiRadArmorItem;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class NuclearIndustryModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NuclearIndustryMod.MODID);
	public static final RegistryObject<Item> NUKE = block(NuclearIndustryModBlocks.NUKE);
	public static final RegistryObject<Item> RADIOACTIVE_MELT = block(NuclearIndustryModBlocks.RADIOACTIVE_MELT);
	public static final RegistryObject<Item> BURNT_PLANK = block(NuclearIndustryModBlocks.BURNT_PLANK);
	public static final RegistryObject<Item> BURNT_WOOD = block(NuclearIndustryModBlocks.BURNT_WOOD);
	public static final RegistryObject<Item> RADIOACTIVE_DIRT = block(NuclearIndustryModBlocks.RADIOACTIVE_DIRT);
	public static final RegistryObject<Item> BURNT_GRASS = block(NuclearIndustryModBlocks.BURNT_GRASS);
	public static final RegistryObject<Item> URANIUM_INGOT = REGISTRY.register("uranium_ingot", () -> new UraniumIngotItem());
	public static final RegistryObject<Item> URANIUM_ORE = block(NuclearIndustryModBlocks.URANIUM_ORE);
	public static final RegistryObject<Item> URANIUM_BLOCK = block(NuclearIndustryModBlocks.URANIUM_BLOCK);
	public static final RegistryObject<Item> ENRICHED_URANIUM = REGISTRY.register("enriched_uranium", () -> new EnrichedUraniumItem());
	public static final RegistryObject<Item> FISSION_CORE = REGISTRY.register("fission_core", () -> new FissionCoreItem());
	public static final RegistryObject<Item> LEAD_INGOT = REGISTRY.register("lead_ingot", () -> new LeadIngotItem());
	public static final RegistryObject<Item> LEAD_ORE = block(NuclearIndustryModBlocks.LEAD_ORE);
	public static final RegistryObject<Item> LEAD_BLOCK = block(NuclearIndustryModBlocks.LEAD_BLOCK);
	public static final RegistryObject<Item> URANIUM_NUGGET = REGISTRY.register("uranium_nugget", () -> new UraniumNuggetItem());
	public static final RegistryObject<Item> REINFORCED_CONCRETE = block(NuclearIndustryModBlocks.REINFORCED_CONCRETE);
	public static final RegistryObject<Item> FALLOUT = block(NuclearIndustryModBlocks.FALLOUT);
	public static final RegistryObject<Item> IRON_PLATE = REGISTRY.register("iron_plate", () -> new IronPlateItem());
	public static final RegistryObject<Item> HAMMER = REGISTRY.register("hammer", () -> new HammerItem());
	public static final RegistryObject<Item> STEEL_INGOT = REGISTRY.register("steel_ingot", () -> new SteelIngotItem());
	public static final RegistryObject<Item> STEEL_BLOCK = block(NuclearIndustryModBlocks.STEEL_BLOCK);
	public static final RegistryObject<Item> STEEL_PLATE = REGISTRY.register("steel_plate", () -> new SteelPlateItem());
	public static final RegistryObject<Item> NEUTRON_REFLECTOR = REGISTRY.register("neutron_reflector", () -> new NeutronReflectorItem());
	public static final RegistryObject<Item> ANTI_RAD_CLOTH = REGISTRY.register("anti_rad_cloth", () -> new AntiRadClothItem());
	public static final RegistryObject<Item> ANTI_RAD_ARMOR_HELMET = REGISTRY.register("anti_rad_armor_helmet", () -> new AntiRadArmorItem.Helmet());
	public static final RegistryObject<Item> ANTI_RAD_ARMOR_CHESTPLATE = REGISTRY.register("anti_rad_armor_chestplate", () -> new AntiRadArmorItem.Chestplate());
	public static final RegistryObject<Item> ANTI_RAD_ARMOR_LEGGINGS = REGISTRY.register("anti_rad_armor_leggings", () -> new AntiRadArmorItem.Leggings());
	public static final RegistryObject<Item> ANTI_RAD_ARMOR_BOOTS = REGISTRY.register("anti_rad_armor_boots", () -> new AntiRadArmorItem.Boots());
	public static final RegistryObject<Item> LEAD_DUST = REGISTRY.register("lead_dust", () -> new LeadDustItem());
	public static final RegistryObject<Item> IRON_DUST = REGISTRY.register("iron_dust", () -> new IronDustItem());
	public static final RegistryObject<Item> STEEL_DUST = REGISTRY.register("steel_dust", () -> new SteelDustItem());
	public static final RegistryObject<Item> SMASHER = block(NuclearIndustryModBlocks.SMASHER);
	public static final RegistryObject<Item> URANIUM_DUST = REGISTRY.register("uranium_dust", () -> new UraniumDustItem());
	public static final RegistryObject<Item> SMALL_PILE_OF_ENRICHED_URANIUM_DUST = REGISTRY.register("small_pile_of_enriched_uranium_dust", () -> new SmallPileOfEnrichedUraniumDustItem());
	public static final RegistryObject<Item> CENTRIFUGE = block(NuclearIndustryModBlocks.CENTRIFUGE);
	public static final RegistryObject<Item> ENRICHED_URANIUM_DUST = REGISTRY.register("enriched_uranium_dust", () -> new EnrichedUraniumDustItem());
	public static final RegistryObject<Item> MOTOR = REGISTRY.register("motor", () -> new MotorItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
