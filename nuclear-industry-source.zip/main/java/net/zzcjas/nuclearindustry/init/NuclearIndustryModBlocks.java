
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.block.UraniumOreBlock;
import net.zzcjas.nuclearindustry.block.UraniumBlockBlock;
import net.zzcjas.nuclearindustry.block.ThermonuclearBombBlock;
import net.zzcjas.nuclearindustry.block.SteelBlockBlock;
import net.zzcjas.nuclearindustry.block.SmasherBlock;
import net.zzcjas.nuclearindustry.block.ReinforcedConcreteBlock;
import net.zzcjas.nuclearindustry.block.RadioactiveMeltBlock;
import net.zzcjas.nuclearindustry.block.RadioactiveDirtBlock;
import net.zzcjas.nuclearindustry.block.NukeBlock;
import net.zzcjas.nuclearindustry.block.LeadOreBlock;
import net.zzcjas.nuclearindustry.block.LeadBlockBlock;
import net.zzcjas.nuclearindustry.block.FalloutBlock;
import net.zzcjas.nuclearindustry.block.CentrifugeBlock;
import net.zzcjas.nuclearindustry.block.BurntWoodBlock;
import net.zzcjas.nuclearindustry.block.BurntPlankBlock;
import net.zzcjas.nuclearindustry.block.BurntGrassBlock;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class NuclearIndustryModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, NuclearIndustryMod.MODID);
	public static final RegistryObject<Block> NUKE = REGISTRY.register("nuke", () -> new NukeBlock());
	public static final RegistryObject<Block> RADIOACTIVE_MELT = REGISTRY.register("radioactive_melt", () -> new RadioactiveMeltBlock());
	public static final RegistryObject<Block> BURNT_PLANK = REGISTRY.register("burnt_plank", () -> new BurntPlankBlock());
	public static final RegistryObject<Block> BURNT_WOOD = REGISTRY.register("burnt_wood", () -> new BurntWoodBlock());
	public static final RegistryObject<Block> RADIOACTIVE_DIRT = REGISTRY.register("radioactive_dirt", () -> new RadioactiveDirtBlock());
	public static final RegistryObject<Block> BURNT_GRASS = REGISTRY.register("burnt_grass", () -> new BurntGrassBlock());
	public static final RegistryObject<Block> URANIUM_ORE = REGISTRY.register("uranium_ore", () -> new UraniumOreBlock());
	public static final RegistryObject<Block> URANIUM_BLOCK = REGISTRY.register("uranium_block", () -> new UraniumBlockBlock());
	public static final RegistryObject<Block> LEAD_ORE = REGISTRY.register("lead_ore", () -> new LeadOreBlock());
	public static final RegistryObject<Block> LEAD_BLOCK = REGISTRY.register("lead_block", () -> new LeadBlockBlock());
	public static final RegistryObject<Block> REINFORCED_CONCRETE = REGISTRY.register("reinforced_concrete", () -> new ReinforcedConcreteBlock());
	public static final RegistryObject<Block> FALLOUT = REGISTRY.register("fallout", () -> new FalloutBlock());
	public static final RegistryObject<Block> STEEL_BLOCK = REGISTRY.register("steel_block", () -> new SteelBlockBlock());
	public static final RegistryObject<Block> SMASHER = REGISTRY.register("smasher", () -> new SmasherBlock());
	public static final RegistryObject<Block> CENTRIFUGE = REGISTRY.register("centrifuge", () -> new CentrifugeBlock());
	public static final RegistryObject<Block> THERMONUCLEAR_BOMB = REGISTRY.register("thermonuclear_bomb", () -> new ThermonuclearBombBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
