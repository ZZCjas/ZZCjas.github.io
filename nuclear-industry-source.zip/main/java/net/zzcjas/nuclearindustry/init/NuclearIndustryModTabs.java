
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

public class NuclearIndustryModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NuclearIndustryMod.MODID);
	public static final RegistryObject<CreativeModeTab> NUCLEAR_INDUSTRY_MATERIAL = REGISTRY.register("nuclear_industry_material",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.nuclear_industry_material")).icon(() -> new ItemStack(NuclearIndustryModItems.URANIUM_INGOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModItems.URANIUM_INGOT.get());
				tabData.accept(NuclearIndustryModItems.ENRICHED_URANIUM.get());
				tabData.accept(NuclearIndustryModItems.STEEL_INGOT.get());
				tabData.accept(NuclearIndustryModItems.LEAD_INGOT.get());
				tabData.accept(NuclearIndustryModBlocks.LEAD_ORE.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.URANIUM_ORE.get().asItem());
				tabData.accept(NuclearIndustryModItems.NEUTRON_REFLECTOR.get());
				tabData.accept(NuclearIndustryModItems.IRON_PLATE.get());
				tabData.accept(NuclearIndustryModItems.STEEL_PLATE.get());
				tabData.accept(NuclearIndustryModItems.ANTI_RAD_CLOTH.get());
				tabData.accept(NuclearIndustryModItems.LEAD_DUST.get());
				tabData.accept(NuclearIndustryModItems.IRON_DUST.get());
				tabData.accept(NuclearIndustryModItems.STEEL_DUST.get());
				tabData.accept(NuclearIndustryModItems.URANIUM_DUST.get());
				tabData.accept(NuclearIndustryModItems.ENRICHED_URANIUM_DUST.get());
				tabData.accept(NuclearIndustryModItems.SMALL_PILE_OF_ENRICHED_URANIUM_DUST.get());
				tabData.accept(NuclearIndustryModItems.URANIUM_NUGGET.get());
				tabData.accept(NuclearIndustryModBlocks.REINFORCED_CONCRETE.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.LEAD_BLOCK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.STEEL_BLOCK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.URANIUM_BLOCK.get().asItem());
				tabData.accept(NuclearIndustryModItems.MOTOR.get());
				tabData.accept(NuclearIndustryModItems.FISSION_CORE.get());
				tabData.accept(NuclearIndustryModItems.RED_STONE_BATTERY.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> NUCLEAR_EXPLOSION_PRODUCTS = REGISTRY.register("nuclear_explosion_products",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.nuclear_explosion_products")).icon(() -> new ItemStack(NuclearIndustryModBlocks.RADIOACTIVE_MELT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModBlocks.RADIOACTIVE_MELT.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_PLANK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_WOOD.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.RADIOACTIVE_DIRT.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_GRASS.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.FALLOUT.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> NI = REGISTRY.register("ni",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.ni")).icon(() -> new ItemStack(NuclearIndustryModBlocks.SMASHER.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModBlocks.SMASHER.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.CENTRIFUGE.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.NUKE.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> NUCLEAR_INDUSTRY_DECORATIONS_TOOLS = REGISTRY.register("nuclear_industry_decorations_tools",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.nuclear_industry_decorations_tools")).icon(() -> new ItemStack(NuclearIndustryModItems.HAMMER.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModItems.HAMMER.get());
				tabData.accept(NuclearIndustryModItems.ANTI_RAD_ARMOR_HELMET.get());
				tabData.accept(NuclearIndustryModItems.ANTI_RAD_ARMOR_CHESTPLATE.get());
				tabData.accept(NuclearIndustryModItems.ANTI_RAD_ARMOR_LEGGINGS.get());
				tabData.accept(NuclearIndustryModItems.ANTI_RAD_ARMOR_BOOTS.get());
			})

					.build());
}
