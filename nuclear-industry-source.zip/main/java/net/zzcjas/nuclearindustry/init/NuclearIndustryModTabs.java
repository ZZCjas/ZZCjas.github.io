
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

public class NuclearIndustryModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NuclearIndustryMod.MODID);
	public static final RegistryObject<CreativeModeTab> NI = REGISTRY.register("ni",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.ni")).icon(() -> new ItemStack(NuclearIndustryModBlocks.NUKE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModBlocks.NUKE.get().asItem());
				tabData.accept(NuclearIndustryModItems.LEAD_INGOT.get());
				tabData.accept(NuclearIndustryModItems.URANIUM_INGOT.get());
				tabData.accept(NuclearIndustryModItems.ENRICHED_URANIUM.get());
				tabData.accept(NuclearIndustryModItems.FISSION_CORE.get());
				tabData.accept(NuclearIndustryModBlocks.LEAD_ORE.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.URANIUM_ORE.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.URANIUM_BLOCK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.LEAD_BLOCK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.RADIOACTIVE_MELT.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_PLANK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_WOOD.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.RADIOACTIVE_DIRT.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_GRASS.get().asItem());
				tabData.accept(NuclearIndustryModItems.URANIUM_NUGGET.get());
				tabData.accept(NuclearIndustryModBlocks.REINFORCED_CONCRETE.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.FALLOUT.get().asItem());
			}).withSearchBar().build());
}
