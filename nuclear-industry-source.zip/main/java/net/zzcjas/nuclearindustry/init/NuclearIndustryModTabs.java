
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

public class NuclearIndustryModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NuclearIndustryMod.MODID);
	public static final RegistryObject<CreativeModeTab> NUCLEAR_INDUSTRY_MATERIAL = REGISTRY.register("nuclear_industry_material",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.nuclear_industry_material")).icon(() -> new ItemStack(NuclearIndustryModItems.URANIUM_INGOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModBlocks.URANIUM_ORE.get().asItem());
				tabData.accept(NuclearIndustryModItems.URANIUM_NUGGET.get());
				tabData.accept(NuclearIndustryModItems.URANIUM_INGOT.get());
				tabData.accept(NuclearIndustryModBlocks.URANIUM_BLOCK.get().asItem());
				tabData.accept(NuclearIndustryModItems.ENRICHED_URANIUM.get());
				tabData.accept(NuclearIndustryModItems.LEAD_INGOT.get());
				tabData.accept(NuclearIndustryModBlocks.LEAD_ORE.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.LEAD_BLOCK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.REINFORCED_CONCRETE.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> NUCLEAR_EXPLOSION_PRODUCTS = REGISTRY.register("nuclear_explosion_products",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.nuclear_explosion_products")).icon(() -> new ItemStack(NuclearIndustryModBlocks.RADIOACTIVE_MELT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModBlocks.RADIOACTIVE_MELT.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_PLANK.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_WOOD.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.RADIOACTIVE_DIRT.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.BURNT_GRASS.get().asItem());
				tabData.accept(NuclearIndustryModBlocks.FALLOUT.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> NI = REGISTRY.register("ni",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nuclear_industry.ni")).icon(() -> new ItemStack(NuclearIndustryModBlocks.NUKE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NuclearIndustryModBlocks.NUKE.get().asItem());
				tabData.accept(NuclearIndustryModItems.FISSION_CORE.get());
			})

					.build());
}
