
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.potion.AntiRadiationMobEffect;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

public class NuclearIndustryModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, NuclearIndustryMod.MODID);
	public static final RegistryObject<MobEffect> ANTI_RADIATION = REGISTRY.register("anti_radiation", () -> new AntiRadiationMobEffect());
}
