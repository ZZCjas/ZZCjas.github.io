
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

public class NuclearIndustryModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, NuclearIndustryMod.MODID);
	public static final RegistryObject<SoundEvent> NUCLEAREXPLOSION = REGISTRY.register("nuclearexplosion", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("nuclear_industry", "nuclearexplosion")));
}
