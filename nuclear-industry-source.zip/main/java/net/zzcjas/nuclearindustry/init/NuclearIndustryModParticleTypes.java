
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.zzcjas.nuclearindustry.init;

import net.zzcjas.nuclearindustry.NuclearIndustryMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

public class NuclearIndustryModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, NuclearIndustryMod.MODID);
	public static final RegistryObject<SimpleParticleType> NUKE_SMOKE = REGISTRY.register("nuke_smoke", () -> new SimpleParticleType(true));
}
