package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.explosion.nuclear.HydroCraterGenerator;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModParticleTypes;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModBlocks;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.util.RandomSource;
import net.minecraft.server.TickTask;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandFunction;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
//import net.zzcjas.nuclearindustry.entity.NukeTorexEntity;

import java.util.Optional;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraftforge.fml.ModList;

public class HydroNukeStartProcedure {
    public static void execute(LevelAccessor world, double x, double y, double z) {
        if (world instanceof ServerLevel _level) {
        	_level.explode(null, x, y, z, 35, Level.ExplosionInteraction.TNT);
            if (!_level.isClientSide()) {
                _level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("nuclear_industry:nuclearexplosion")), SoundSource.BLOCKS, 100, 1);
            } else {
                _level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("nuclear_industry:nuclearexplosion")), SoundSource.BLOCKS, 100, 1, false);
            }
            world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
            //float scale = 160.0F; // 与爆炸威力匹配
			//NukeTorexEntity.statFac(_level, x, y, z, scale);
            HydroCraterGenerator.generateCrater(
                _level,
                new BlockPos((int)x,(int)y,(int)z),
                NuclearIndustryModBlocks.RADIOACTIVE_MELT.get(),
                NuclearIndustryModBlocks.BURNT_WOOD.get(),
                NuclearIndustryModBlocks.BURNT_PLANK.get(),
                NuclearIndustryModBlocks.BURNT_GRASS.get(),
                NuclearIndustryModBlocks.RADIOACTIVE_DIRT.get()
            );

           AtomicBoolean stopParticles = new AtomicBoolean(false);
		   int currentTick = _level.getServer().getTickCount();
		
		    // 立即设为晴天
		    _level.setWeatherParameters(24000, 0, false, false);
		
		    // 粒子生成任务：每隔2秒（40 ticks）在半径160格内生成烟雾和火焰
//		    Runnable particleTask = new Runnable() {
//		        @Override
//		        public void run() {
//		            if (stopParticles.get()) return; // 下雨后停止
//		
//		            RandomSource random = _level.random;
//		            int centerX = (int) x, centerY = (int) y, centerZ = (int) z;
//		            int radius = 160;
//		
//		            for (int i = 0; i < 200; i++) { // 每次生成200个粒子
//		                double offsetX = (random.nextDouble() * 2 - 1) * radius;
//		                double offsetY = (random.nextDouble() * 2 - 1) * radius * 0.5; // 垂直范围减半
//		                double offsetZ = (random.nextDouble() * 2 - 1) * radius;
//		
//		                // 确保点在球体内
//		                if (offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ > radius * radius)
//		                    continue;
//		
//		                double px = centerX + offsetX;
//		                double py = centerY + offsetY;
//		                double pz = centerZ + offsetZ;
//		
//		                if (random.nextBoolean()) {
//		                    _level.sendParticles(NuclearIndustryModParticleTypes.NUKE_SMOKE.get(), px, py, pz, 1, 0, 0, 0, 0);
//		                } else {
//		                    _level.sendParticles(ParticleTypes.FLAME, px, py, pz, 1, 0, 0, 0, 0);
//		                }
//		            }
//		
//		            // 40 ticks后再次执行
//		            _level.getServer().tell(new TickTask(currentTick + 40, this));
//		        }
//		    };
//		
//		    // 立即启动粒子任务
//		    _level.getServer().tell(new TickTask(currentTick, particleTask));
		
		    // 1分钟后（1200 ticks）开始下雨，并停止粒子
		    _level.getServer().tell(new TickTask(currentTick + 1200, () -> {
		        stopParticles.set(true);
		        _level.setWeatherParameters(0, 2400, true, false); // 下雨持续2400 ticks
		        System.out.println("[NUCLEAR_INDUSTRY] Weather changed to rain (2 minutes duration).");
		    }));
		
		    // 3分钟后（1200+2400 ticks）强制转晴
		    _level.getServer().tell(new TickTask(currentTick + 1200 + 2400, () -> {
		        _level.setWeatherParameters(24000, 0, false, false);
		        System.out.println("[NUCLEAR_INDUSTRY] Weather cleared to sunny.");
		    }));

            // ========== 检测Mekanism模组并添加辐射 ==========
            if (ModList.get().isLoaded("mekanism")) {
                // 计算辐射覆盖区域的最大半径（基于CraterGenerator的常量推算）
                final int MAX_RAY_DISTANCE = 250; // 从CraterGenerator复制
                final float ZONE_4_RADIUS_MULTIPLIER = 1.5F;
                final double MAX_RADIUS = MAX_RAY_DISTANCE * ZONE_4_RADIUS_MULTIPLIER + 24.0; // 约330
                final int STEP = 90; // 步长，保证任何点至少被一个半径80的源覆盖（90/2 * sqrt(3) ≈ 77.94 < 80）

                // 生成网格点，确保覆盖以(x,y,z)为中心、半径为MAX_RADIUS的球体
                List<Vec3> radiationPoints = new ArrayList<>();
                int centerX = (int) Math.floor(x);
                int centerY = (int) Math.floor(y);
                int centerZ = (int) Math.floor(z);
                int maxIndex = (int) Math.ceil(MAX_RADIUS / STEP);
                for (int i = -maxIndex; i <= maxIndex; i++) {
                    for (int j = -maxIndex; j <= maxIndex; j++) {
                        for (int k = -maxIndex; k <= maxIndex; k++) {
                            double dx = i * STEP;
                            double dy = j * STEP;
                            double dz = k * STEP;
                            double distSq = dx * dx + dy * dy + dz * dz;
                            if (distSq <= MAX_RADIUS * MAX_RADIUS) {
                                radiationPoints.add(new Vec3(centerX + dx, centerY + dy, centerZ + dz));
                            }
                        }
                    }
                }

                // 在每个点执行辐射添加指令（每个源使用最大辐射值9999），并抑制命令输出
                String command = "mek radiation add 9999";
                for (Vec3 point : radiationPoints) {
                    CommandSourceStack silentSource = new CommandSourceStack(
                        CommandSource.NULL,
                        point,
                        Vec2.ZERO,
                        _level,
                        4,
                        "",
                        Component.literal(""),
                        _level.getServer(),
                        null
                    ).withSuppressedOutput();
                    _level.getServer().getCommands().performPrefixedCommand(silentSource, command);
                }
                System.out.println("[NUCLEAR_INDUSTRY] Added " + radiationPoints.size() + " Mekanism radiation sources.");
            } else {
                System.out.println("[NUCLEAR_INDUSTRY] Mekanism mod not loaded, skipping radiation.");
            }
        }
    }
}