package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.init.NuclearIndustryModMobEffects;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

public class TooMuchRadioProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(NuclearIndustryModMobEffects.ANTI_RADIATION.get()) ? _livEnt.getEffect(NuclearIndustryModMobEffects.ANTI_RADIATION.get()).getAmplifier() : 0) < 3
				|| !(entity instanceof LivingEntity _livEnt1 && _livEnt1.hasEffect(NuclearIndustryModMobEffects.ANTI_RADIATION.get()))) {
			entity.setSecondsOnFire(1);
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 2));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 60, 2));
		}
	}
}
