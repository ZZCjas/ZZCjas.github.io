package net.zzcjas.nuclearindustry.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModGameRules;
import net.zzcjas.nuclearindustry.util.ListHelper;
import net.zzcjas.nuclearindustry.util.ReflectionHelper;

import java.lang.reflect.Field;

public class MatterSmashingProcedure {

    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null || world.isClientSide()) return;

        ServerLevel serverLevel = (ServerLevel) world;

        boolean aggressive = serverLevel.getGameRules().getBoolean(NuclearIndustryModGameRules.DIVINE_SLAYING_AGGRESSIVE);
        final boolean finalAggressive = aggressive;

        entity.getPersistentData().putBoolean("nuclearindustry:marked_for_divine_slaying", true);

        LightningBolt lightning = EntityType.LIGHTNING_BOLT.create(serverLevel);
        lightning.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
        lightning.setVisualOnly(true);
        serverLevel.addFreshEntity(lightning);

        if (entity instanceof LivingEntity livingEntity) {
            livingEntity.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
            if (livingEntity instanceof Player player) {
                player.getInventory().clearContent();
                player.inventoryMenu.broadcastChanges();
            }
            livingEntity.removeAllEffects();
        }

        serverLevel.sendParticles(ParticleTypes.POOF, x, y + 0.5, z, 15, 0.5, 0.5, 0.5, 0.0);

        DamageSource divineSlaying = new DamageSource(serverLevel.registryAccess()
                .registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                        new ResourceLocation("nuclear_industry", "divine_slaying"))));

        if (entity instanceof LivingEntity livingTarget) {
            livingTarget.hurt(divineSlaying, Float.MAX_VALUE);
            livingTarget.hurt(divineSlaying, livingTarget.getHealth());

//            if (aggressive) {
//                // 激进模式：反射修改 health 字段
//                try {
//                    Field healthField = LivingEntity.class.getDeclaredField("health");
//                    healthField.setAccessible(true);
//                    healthField.setFloat(livingTarget, 0.0f);
//                } catch (Exception e) {
//                    livingTarget.setHealth(0.0f);
//                }
//                // 递归清零所有数值字段
//                ReflectionHelper.zeroOutNumericFields(livingTarget);
//            } else {
                livingTarget.setHealth(0.0f);
            //}

            serverLevel.broadcastEntityEvent(livingTarget, (byte) 3);
            if (livingTarget instanceof Player player) {
                player.sendSystemMessage(player.getCombatTracker().getDeathMessage());
            }
            livingTarget.die(divineSlaying);
        }

        annihilateEntity(entity, aggressive);

        NuclearIndustryMod.queueServerWork(1, () -> {
            if (entity.isAlive()) {
                DamageSource divineSlayingAgain = new DamageSource(serverLevel.registryAccess()
                        .registryOrThrow(Registries.DAMAGE_TYPE)
                        .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                new ResourceLocation("nuclear_industry", "divine_slaying"))));

                Runnable killTask = new Runnable() {
                    @Override
                    public void run() {
                        if (entity.isAlive()) {
                            entity.hurt(divineSlayingAgain, 9999999.0f);
                            NuclearIndustryMod.queueServerWork(1, this);
                        }
                    }
                };
                killTask.run();
            }
        });
    }

    private static void annihilateEntity(Entity entity, boolean aggressive) {
        if (!(entity instanceof LivingEntity living)) return;

//        if (aggressive) {
//            try {
//                Field healthField = LivingEntity.class.getDeclaredField("health");
//                healthField.setAccessible(true);
//                healthField.setFloat(living, 0.0f);
//            } catch (Exception e) {
//                living.setHealth(0);
//            }
//            ReflectionHelper.zeroOutNumericFields(living);
//        } else {
            living.setHealth(0);
        //}

        living.setPos(-9999, -9999, -9999);

        if (!(living instanceof Player)) {
            ListHelper.addEntityToRemoveList(living);
            living.discard();
            living.setInvisible(true);
            living.removeVehicle();
            living.remove(Entity.RemovalReason.DISCARDED);
            living.onRemovedFromWorld();
            living.setRemoved(Entity.RemovalReason.DISCARDED);
        }

        living.setHealth(0);
    }
}