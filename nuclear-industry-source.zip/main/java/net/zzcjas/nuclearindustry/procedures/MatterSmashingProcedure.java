package net.zzcjas.nuclearindustry.procedures;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;
import net.zzcjas.nuclearindustry.util.ListHelper;

public class MatterSmashingProcedure {

    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null || world.isClientSide()) return;

        ServerLevel serverLevel = (ServerLevel) world;

        // ===================== 0. 打上湮灭标记 =====================
        entity.getPersistentData().putBoolean("nuclearindustry:marked_for_divine_slaying", true);

        // ===================== 1. 视觉闪电 =====================
        LightningBolt lightning = EntityType.LIGHTNING_BOLT.create(serverLevel);
        lightning.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
        lightning.setVisualOnly(true);
        serverLevel.addFreshEntity(lightning);

        // ===================== 2. 清空所有装备+背包+药水效果 =====================
        if (entity instanceof LivingEntity livingEntity) {
            livingEntity.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
            if (livingEntity instanceof Player player) {
                player.getInventory().clearContent();
                player.inventoryMenu.broadcastChanges();
            }
            livingEntity.removeAllEffects();
        }

        // ===================== 3. 双重神圣斩杀伤害 =====================
        if (entity instanceof LivingEntity livingTarget) {
            DamageSource divineSlaying = new DamageSource(serverLevel.registryAccess()
                    .registryOrThrow(Registries.DAMAGE_TYPE)
                    .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                            new ResourceLocation("nuclear_industry", "divine_slaying"))));

            livingTarget.hurt(divineSlaying, Float.MAX_VALUE);
            livingTarget.hurt(divineSlaying, livingTarget.getHealth());

            livingTarget.setHealth(0.0F);
            serverLevel.broadcastEntityEvent(livingTarget, (byte) 3);
            if (livingTarget instanceof Player player) {
                player.sendSystemMessage(player.getCombatTracker().getDeathMessage());
            }
            livingTarget.die(divineSlaying);
        }

        // ===================== 4. 抹杀模式（强制移除） =====================
        annihilateEntity(entity);

        // ===================== 5. 等待 1 tick 后检测，若仍存活则进入高频补刀 =====================
        NuclearIndustryMod.queueServerWork(1, () -> {
            if (entity.isAlive()) {
                DamageSource divineSlaying = new DamageSource(serverLevel.registryAccess()
                        .registryOrThrow(Registries.DAMAGE_TYPE)
                        .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                new ResourceLocation("nuclear_industry", "divine_slaying"))));

                Runnable killTask = new Runnable() {
                    @Override
                    public void run() {
                        if (entity.isAlive()) {
                            entity.hurt(divineSlaying, 9999.0F);
                            NuclearIndustryMod.queueServerWork(1, this);
                        }
                    }
                };
                killTask.run(); // 立即执行第一次，后续由自身调度
            }
        });
    }
    private static void annihilateEntity(Entity entity) {
        if (!(entity instanceof LivingEntity living))
            return;

        living.setPos(-9999, -9999, -9999);

        if (!(living instanceof Player)) {
            ListHelper.addEntityToRemoveList(living);
            living.discard();
            living.setInvisible(true);
            living.removeVehicle();
            living.remove(Entity.RemovalReason.DISCARDED);
            living.onRemovedFromWorld();
            living.setRemoved(Entity.RemovalReason.DISCARDED);
        }

        living.setHealth(0);
    }
}