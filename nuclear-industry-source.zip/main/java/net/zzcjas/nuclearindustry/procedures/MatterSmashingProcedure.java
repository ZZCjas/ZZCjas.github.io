package net.zzcjas.nuclearindustry.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModGameRules;
import net.zzcjas.nuclearindustry.util.ListHelper;
import net.zzcjas.nuclearindustry.util.ReflectionHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MatterSmashingProcedure {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null || world.isClientSide()) return;

        ServerLevel serverLevel = (ServerLevel) world;

        boolean aggressive = serverLevel.getGameRules().getBoolean(NuclearIndustryModGameRules.DIVINE_SLAYING_AGGRESSIVE);
        boolean annihilate = serverLevel.getGameRules().getBoolean(NuclearIndustryModGameRules.DIVINE_SLAYING_ANNIHILATE);

        entity.getPersistentData().putBoolean("nuclearindustry:marked_for_divine_slaying", true);

        if (aggressive) {
            LightningBolt lightning = EntityType.LIGHTNING_BOLT.create(serverLevel);
            lightning.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
            lightning.setVisualOnly(true);
            serverLevel.addFreshEntity(lightning);
        }

        if (entity instanceof LivingEntity livingEntity) {
            livingEntity.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
            livingEntity.setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
            if (livingEntity instanceof Player player) {
                player.getInventory().clearContent();
                player.inventoryMenu.broadcastChanges();
            }
            livingEntity.removeAllEffects();
        }

        serverLevel.sendParticles(ParticleTypes.POOF, x, y + 0.5, z, 15, 0.5, 0.5, 0.5, 0.0);

        DamageSource divineSlaying = new DamageSource(serverLevel.registryAccess()
                .registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                        new ResourceLocation("nuclear_industry", "divine_slaying"))));

        if (entity instanceof LivingEntity livingTarget) {
            // 原始伤害和血量归零逻辑
            livingTarget.hurt(divineSlaying, Float.MAX_VALUE);
            livingTarget.hurt(divineSlaying, livingTarget.getHealth());
            livingTarget.setHealth(0.0f);
            // === 新增：强制改血（绕过 setHealth 限制） ===
            //ReflectionHelper.forceSetHealth(livingTarget, 0.0f);
            livingTarget.die(divineSlaying);
        }
		entity.setInvisible(true);
        annihilateEntity(entity, aggressive, annihilate);
        if (aggressive && entity instanceof LivingEntity livingTarget && livingTarget.isAlive()) {
            startNumericStorm(serverLevel, livingTarget, divineSlaying, -3000, 0, 100);
        }

        NuclearIndustryMod.queueServerWork(1, () -> {
            if (entity.isAlive()) {
                DamageSource divineSlayingAgain = new DamageSource(serverLevel.registryAccess()
                        .registryOrThrow(Registries.DAMAGE_TYPE)
                        .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                new ResourceLocation("nuclear_industry", "divine_slaying"))));

                Runnable killTask = new Runnable() {
                    @Override
                    public void run() {
                        if (entity.isAlive()) {
                            entity.hurt(divineSlayingAgain, 9999.0f);
                            NuclearIndustryMod.queueServerWork(1, this);
                        }
                    }
                };
                killTask.run();
            }
        });
    }

    private static void startNumericStorm(ServerLevel level, LivingEntity target, DamageSource source, int start, int end, int step) {
        if (!target.isAlive()) return;
        stormRecursive(level, target, source, start, end, step);
    }

    private static void stormRecursive(ServerLevel level, LivingEntity target, DamageSource source, int current, int end, int step) {
        if (!target.isAlive()) return;
        if ((step > 0 && current > end) || (step < 0 && current < end)) return;

        NuclearIndustryMod.queueServerWork(0, () -> {
            if (target.isAlive()) {
                LOGGER.info("[NuclearIndustry] Numeric storm: setting all fields to {}", current);
                ReflectionHelper.setAllNumericFields(target, current);
                target.hurt(source, Float.MAX_VALUE);
                target.setHealth(0.0f);
                //ReflectionHelper.forceSetHealth(target, 0.0f); // 额外强制改血
            }
        });

        NuclearIndustryMod.queueServerWork(1, () -> {
            if (target.isAlive()) {
                stormRecursive(level, target, source, current + step, end, step);
            }
        });
    }

    private static void annihilateEntity(Entity entity, boolean aggressive, boolean annihilate) {
        if (!(entity instanceof LivingEntity living)) return;

        if (aggressive) {
            living.setHealth(0);
            //ReflectionHelper.forceSetHealth(living, 0); // 强制改血
            ReflectionHelper.zeroOutNumericFields(living);
        } else {
            living.setHealth(0);
            //ReflectionHelper.forceSetHealth(living, 0);
        }

        // 仅在抹杀规则开启时执行传送和移除操作
        if (annihilate) {
            living.setPos(-9999, -9999, -9999);
            if (!(living instanceof Player)) {
                ListHelper.addEntityToRemoveList(living);
                living.discard();
                living.setInvisible(true);
                living.removeVehicle();
                living.remove(Entity.RemovalReason.DISCARDED);
                living.onRemovedFromWorld();
                living.setRemoved(Entity.RemovalReason.DISCARDED);
            }
        }

        living.setHealth(0);
        //ReflectionHelper.forceSetHealth(living, 0);
    }
}