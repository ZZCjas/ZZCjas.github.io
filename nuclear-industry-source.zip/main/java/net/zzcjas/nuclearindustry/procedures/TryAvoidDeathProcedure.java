package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.init.NuclearIndustryModItems;
import net.zzcjas.nuclearindustry.NuclearIndustryMod; // 新增导入

import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;
import java.util.concurrent.atomic.AtomicReference;

@Mod.EventBusSubscriber
public class TryAvoidDeathProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		execute(null, world, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		{
			AtomicReference<IItemHandler> _iitemhandlerref = new AtomicReference<>();
			entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(_iitemhandlerref::set);
			if (_iitemhandlerref.get() != null) {
				for (int _idx = 0; _idx < _iitemhandlerref.get().getSlots(); _idx++) {
					ItemStack itemstackiterator = _iitemhandlerref.get().getStackInSlot(_idx).copy();
					if (itemstackiterator.getItem() == NuclearIndustryModItems.MATTER_SMASHER.get()) {
						// 复活持有者并给予增益
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 1200, 10));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 100, 255));
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth((float) Math.max(20, entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1));

						// ===== 对攻击者的反杀处理 =====
						if (sourceentity instanceof LivingEntity _livingAttacker) {
							// 构造 divine_slaying 伤害源
							DamageSource divineSlaying = new DamageSource(_livingAttacker.level().registryAccess()
									.registryOrThrow(Registries.DAMAGE_TYPE)
									.getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
											new ResourceLocation("nuclear_industry:divine_slaying"))));

							// 1. 造成等同于最大生命值的 divine_slaying 伤害
							_livingAttacker.hurt(divineSlaying, _livingAttacker.getMaxHealth());

							// 2. 将攻击者生命值设为 0（强制死亡）
							_livingAttacker.setHealth(0);

							// 3. 延迟 1 tick 后检测，若仍存活则直接删除
							if (!world.isClientSide()) {
								NuclearIndustryMod.queueServerWork(1, () -> {
									if (_livingAttacker.isAlive()) {
										_livingAttacker.discard();
									}
								});
							}
						} else {
							// 如果攻击者不是 LivingEntity（如箭矢、闪电等），直接删除
							if (!world.isClientSide()) {
								sourceentity.discard();
							}
						}

						// 取消死亡事件，防止持有者真正死亡
						if (event != null && event.isCancelable()) {
							event.setCanceled(true);
						}
					}
				}
			}
		}
	}
}