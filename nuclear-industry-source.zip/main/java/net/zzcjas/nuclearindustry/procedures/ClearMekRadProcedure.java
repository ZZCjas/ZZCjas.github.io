package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.init.NuclearIndustryModMobEffects;

import net.minecraftforge.fml.ModList;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

public class ClearMekRadProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(NuclearIndustryModMobEffects.ANTI_RADIATION.get()) ? _livEnt.getEffect(NuclearIndustryModMobEffects.ANTI_RADIATION.get()).getAmplifier() : 0) >= 2) {
			if (ModList.get().isLoaded("mekanism")) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"mekanism radiation\u00A0heal @p");
			}
		}
	}
}
