package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.init.NuclearIndustryModGameRules;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModMobEffects;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.lang.reflect.Field;

public class SuperPowerProcedure {

    public static void execute(Entity entity) {
        if (entity == null) return;

        boolean aggressive = false;
        if (entity.level() instanceof ServerLevel serverLevel) {
            aggressive = serverLevel.getGameRules().getBoolean(NuclearIndustryModGameRules.DIVINE_SLAYING_AGGRESSIVE);
        }

        if (entity instanceof LivingEntity livingEntity && !livingEntity.level().isClientSide()) {
            livingEntity.removeAllEffects();

            livingEntity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 6));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 5));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 255));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.SATURATION, 100, 3));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100, 1));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 10));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 100, 10));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.LUCK, 100, 255));
            livingEntity.addEffect(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 100, 3));

            float targetHealth = Math.max(livingEntity.getMaxHealth(), 20.0f);
			livingEntity.setHealth(targetHealth);
        }

        entity.clearFire();

        if (entity instanceof Player player) {
            player.getAbilities().mayfly = true;
            player.onUpdateAbilities();
        }
    }
}