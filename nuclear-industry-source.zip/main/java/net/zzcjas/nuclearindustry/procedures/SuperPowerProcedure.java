package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.init.NuclearIndustryModMobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.GameRules;

public class SuperPowerProcedure {
    // 可选：记录每个世界是否已设置过规则，避免每 tick 重复执行命令
    // private static final java.util.Map<ServerLevel, Boolean> keepInventorySet = new java.util.HashMap<>();

    public static void execute(Entity entity) {
        if (entity == null) return;
        // 以下为原有的增益效果逻辑
        if (entity instanceof LivingEntity livingEntity && !livingEntity.level().isClientSide()) {
            livingEntity.removeAllEffects();

            livingEntity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 6));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 5));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 255));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.SATURATION, 100, 3));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100, 1));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 10));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 100, 10));
            livingEntity.addEffect(new MobEffectInstance(MobEffects.LUCK, 100, 255));
            livingEntity.addEffect(new MobEffectInstance(NuclearIndustryModMobEffects.ANTI_RADIATION.get(), 100, 3));

            // 修改：将生命值设置为最大生命值与20.0F中的较大值
            livingEntity.setHealth(Math.max(livingEntity.getMaxHealth(), 20.0F));
        }

        entity.clearFire();

        if (entity instanceof Player player) {
            player.getAbilities().mayfly = true;
            player.onUpdateAbilities();
        }
    }
}