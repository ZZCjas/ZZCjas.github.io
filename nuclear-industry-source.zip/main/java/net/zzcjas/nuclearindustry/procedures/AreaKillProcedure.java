package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.init.NuclearIndustryModItems;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;
import net.zzcjas.nuclearindustry.util.ListHelper;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Comparator;

public class AreaKillProcedure {

    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null)
            return;
        if (NuclearIndustryModItems.MATTER_SMASHER.get() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
            if (!(entity instanceof Player _plrCldCheck3 && _plrCldCheck3.getCooldowns().isOnCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()))) {

                final Vec3 _center = new Vec3(x, y, z);
                List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(128), e -> true)
                        .stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();

                for (Entity entityiterator : _entfound) {
                    if (entity == entityiterator || entityiterator instanceof ItemEntity || entityiterator instanceof ExperienceOrb)
                        continue;

                    if (entityiterator instanceof LivingEntity target) {
                        // ========== 0. 打上湮灭标记 ==========
                        target.getPersistentData().putBoolean("nuclearindustry:marked_for_divine_slaying", true);

                        // 视觉闪电
                        if (world instanceof ServerLevel _level) {
                            LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
                            entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(target.getX(), target.getY(), target.getZ())));
                            entityToSpawn.setVisualOnly(true);
                            _level.addFreshEntity(entityToSpawn);
                        }

                        // 爆炸
                        if (world instanceof Level _level && !_level.isClientSide())
                            _level.explode(null, target.getX(), target.getY(), target.getZ(), 3, Level.ExplosionInteraction.TNT);

                        // 清除装备
                        {
                            Entity _entity = target;
                            if (_entity instanceof Player _player) {
                                _player.getInventory().armor.set(0, new ItemStack(Blocks.AIR));
                                _player.getInventory().setChanged();
                            } else if (_entity instanceof LivingEntity _living) {
                                _living.setItemSlot(EquipmentSlot.FEET, new ItemStack(Blocks.AIR));
                            }
                        }
                        {
                            Entity _entity = target;
                            if (_entity instanceof Player _player) {
                                _player.getInventory().armor.set(1, new ItemStack(Blocks.AIR));
                                _player.getInventory().setChanged();
                            } else if (_entity instanceof LivingEntity _living) {
                                _living.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Blocks.AIR));
                            }
                        }
                        {
                            Entity _entity = target;
                            if (_entity instanceof Player _player) {
                                _player.getInventory().armor.set(2, new ItemStack(Blocks.AIR));
                                _player.getInventory().setChanged();
                            } else if (_entity instanceof LivingEntity _living) {
                                _living.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Blocks.AIR));
                            }
                        }
                        {
                            Entity _entity = target;
                            if (_entity instanceof Player _player) {
                                _player.getInventory().armor.set(3, new ItemStack(Blocks.AIR));
                                _player.getInventory().setChanged();
                            } else if (_entity instanceof LivingEntity _living) {
                                _living.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Blocks.AIR));
                            }
                        }
                        if (target instanceof Player _player)
                            _player.getFoodData().setFoodLevel(0);
                        if (target instanceof Player _player)
                            _player.getInventory().clearContent();
                        target.setSecondsOnFire(3600);

                        // 伤害源准备
                        DamageSource divineSlaying = new DamageSource(world.registryAccess()
                                .registryOrThrow(Registries.DAMAGE_TYPE)
                                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                        new ResourceLocation("nuclear_industry:divine_slaying"))));
                        DamageSource fusionExplosion = new DamageSource(world.registryAccess()
                                .registryOrThrow(Registries.DAMAGE_TYPE)
                                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                        new ResourceLocation("nuclear_industry:fusion_explosion"))));

                        target.hurt(divineSlaying, target.getMaxHealth());
                        target.hurt(fusionExplosion, 88888888);
                        target.setHealth(0);
                        target.die(divineSlaying);

                        // ========== 抹杀模式（强制移除） ==========
                        annihilateEntity(target);

                        // ========== 等待 1 tick 后检测，若仍存活则进入高频补刀 ==========
                        if (!world.isClientSide()) {
                            NuclearIndustryMod.queueServerWork(1, () -> {
                                if (target.isAlive()) {
                                    Runnable[] task = new Runnable[1];
                                    task[0] = () -> {
                                        if (target.isAlive()) {
                                            target.hurt(divineSlaying, 20);
                                            if (target.isAlive()) {
                                                NuclearIndustryMod.queueServerWork(1, task[0]);
                                            }
                                        }
                                    };
                                    task[0].run(); // 立即执行第一次
                                }
                            });
                        }
                    }
                }

                if (entity instanceof Player _player)
                    _player.getCooldowns().addCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem(), 20);
            }
        }
    }

    /**
     * 抹杀模式：将实体移至世界之外，执行丢弃与移除操作，最后将血量设为 0。
     */
    private static void annihilateEntity(Entity entity) {
        if (!(entity instanceof LivingEntity living))
            return;

        living.setPos(-9999, -9999, -9999);

        if (!(living instanceof Player)) {
            ListHelper.addEntityToRemoveList(living);
            living.discard();
            living.setInvisible(true);
            living.removeVehicle();
            living.remove(Entity.RemovalReason.DISCARDED);
            living.onRemovedFromWorld();
            living.setRemoved(Entity.RemovalReason.DISCARDED);
        }

        living.setHealth(0);
    }
}