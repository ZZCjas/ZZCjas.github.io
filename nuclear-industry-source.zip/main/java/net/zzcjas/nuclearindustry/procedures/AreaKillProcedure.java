package net.zzcjas.nuclearindustry.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModGameRules;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModItems;
import net.zzcjas.nuclearindustry.util.ListHelper;
import net.zzcjas.nuclearindustry.util.ReflectionHelper;

import java.util.Comparator;
import java.util.List;

public class AreaKillProcedure {

    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null) return;

        if (NuclearIndustryModItems.MATTER_SMASHER.get() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
            if (!(entity instanceof Player _plr && _plr.getCooldowns().isOnCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()))) {

                boolean aggressive = false;
                if (world instanceof ServerLevel serverLevel) {
                    aggressive = serverLevel.getGameRules().getBoolean(NuclearIndustryModGameRules.DIVINE_SLAYING_AGGRESSIVE);
                }
                final boolean finalAggressive = aggressive;

                final Vec3 center = new Vec3(x, y, z);
                List<Entity> targets = world.getEntitiesOfClass(Entity.class, new AABB(center, center).inflate(128), e -> true)
                        .stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(center))).toList();

                for (Entity target : targets) {
                    if (entity == target || target instanceof ItemEntity || target instanceof ExperienceOrb)
                        continue;

                    if (target instanceof LivingEntity livingTarget) {
                        livingTarget.getPersistentData().putBoolean("nuclearindustry:marked_for_divine_slaying", true);

                        if (world instanceof ServerLevel sLevel) {
                            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sLevel);
                            bolt.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(livingTarget.getX(), livingTarget.getY(), livingTarget.getZ())));
                            bolt.setVisualOnly(true);
                            sLevel.addFreshEntity(bolt);
                        }

                        if (world instanceof Level level && !level.isClientSide())
                            level.explode(null, livingTarget.getX(), livingTarget.getY(), livingTarget.getZ(), 3, Level.ExplosionInteraction.TNT);

                        clearEquipment(livingTarget);
                        if (livingTarget instanceof Player player) {
                            player.getFoodData().setFoodLevel(0);
                            player.getInventory().clearContent();
                        }
                        livingTarget.setSecondsOnFire(3600);

                        DamageSource divineSlaying = new DamageSource(world.registryAccess()
                                .registryOrThrow(Registries.DAMAGE_TYPE)
                                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                        new ResourceLocation("nuclear_industry", "divine_slaying"))));
                        DamageSource fusionExplosion = new DamageSource(world.registryAccess()
                                .registryOrThrow(Registries.DAMAGE_TYPE)
                                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                        new ResourceLocation("nuclear_industry", "fusion_explosion"))));

                        livingTarget.hurt(divineSlaying, livingTarget.getMaxHealth());
                        livingTarget.hurt(fusionExplosion, 88888888);
                        livingTarget.setHealth(0);

                        if (world instanceof ServerLevel sLevel) {
                            sLevel.sendParticles(ParticleTypes.POOF, livingTarget.getX(), livingTarget.getY() + 0.5, livingTarget.getZ(), 15, 0.5, 0.5, 0.5, 0.0);
                        }

                        livingTarget.die(divineSlaying);
                        annihilateEntity(livingTarget, aggressive);

                        // 高频补刀：仅伤害，不再清空数据和 setHealth
                        if (!world.isClientSide()) {
                            NuclearIndustryMod.queueServerWork(1, () -> {
                                if (livingTarget.isAlive()) {
                                    Runnable killTask = new Runnable() {
                                        @Override
                                        public void run() {
                                            if (livingTarget.isAlive()) {
                                                livingTarget.hurt(divineSlaying, 9999999);
                                                if (livingTarget.isAlive()) {
                                                    NuclearIndustryMod.queueServerWork(1, this);
                                                }
                                            }
                                        }
                                    };
                                    killTask.run();
                                }
                            });
                        }
                    }
                }

                if (entity instanceof Player player) {
                    player.getCooldowns().addCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem(), 20);
                }
            }
        }
    }

    private static void clearEquipment(LivingEntity living) {
        if (living instanceof Player player) {
            player.getInventory().armor.set(0, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.FEET, new ItemStack(Blocks.AIR));
        }
        if (living instanceof Player player) {
            player.getInventory().armor.set(1, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Blocks.AIR));
        }
        if (living instanceof Player player) {
            player.getInventory().armor.set(2, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Blocks.AIR));
        }
        if (living instanceof Player player) {
            player.getInventory().armor.set(3, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Blocks.AIR));
        }
    }

    private static void annihilateEntity(Entity entity, boolean aggressive) {
        if (!(entity instanceof LivingEntity living)) return;
		living.setHealth(0);
//        if (aggressive) {
//            
//            ReflectionHelper.zeroOutNumericFields(living);
//        } else {
//            living.setHealth(0);
//        }

        living.setPos(-9999, -9999, -9999);

        if (!(living instanceof Player)) {
            ListHelper.addEntityToRemoveList(living);
            living.discard();
            living.setInvisible(true);
            living.removeVehicle();
            living.remove(Entity.RemovalReason.DISCARDED);
            living.onRemovedFromWorld();
            living.setRemoved(Entity.RemovalReason.DISCARDED);
        }

        living.setHealth(0);
    }
}