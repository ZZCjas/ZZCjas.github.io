package net.zzcjas.nuclearindustry.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.zzcjas.nuclearindustry.NuclearIndustryMod;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModGameRules;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModItems;
import net.zzcjas.nuclearindustry.util.HealthOverrideHelper;
import net.zzcjas.nuclearindustry.util.ListHelper;
import net.zzcjas.nuclearindustry.util.ReflectionHelper;

import java.lang.reflect.Field;
import java.util.Comparator;
import java.util.List;

public class AreaKillProcedure {

    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null) return;

        // 检查主手是否为物质粉碎机
        if (NuclearIndustryModItems.MATTER_SMASHER.get() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
            if (!(entity instanceof Player _plr && _plr.getCooldowns().isOnCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()))) {

                // 获取游戏规则
                boolean aggressive = false;
                if (world instanceof ServerLevel serverLevel) {
                    aggressive = serverLevel.getGameRules().getBoolean(NuclearIndustryModGameRules.DIVINE_SLAYING_AGGRESSIVE);
                }
                final Vec3 center = new Vec3(x, y, z);
                List<Entity> targets = world.getEntitiesOfClass(Entity.class, new AABB(center, center).inflate(128), e -> true)
                        .stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(center))).toList();

                for (Entity target : targets) {
                    if (entity == target || target instanceof ItemEntity || target instanceof ExperienceOrb)
                        continue;

                    if (target instanceof LivingEntity livingTarget) {
                        // ========== 0. 湮灭标记 ==========
                        livingTarget.getPersistentData().putBoolean("nuclearindustry:marked_for_divine_slaying", true);

                        // ========== 1. 视觉闪电 ==========
                        if (world instanceof ServerLevel sLevel) {
                            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sLevel);
                            bolt.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(livingTarget.getX(), livingTarget.getY(), livingTarget.getZ())));
                            bolt.setVisualOnly(true);
                            sLevel.addFreshEntity(bolt);
                        }

                        // ========== 2. 爆炸效果 ==========
                        if (world instanceof Level level && !level.isClientSide())
                            level.explode(null, livingTarget.getX(), livingTarget.getY(), livingTarget.getZ(), 3, Level.ExplosionInteraction.TNT);

                        // ========== 3. 清空装备 ==========
                        clearEquipment(livingTarget);
                        if (livingTarget instanceof Player player) {
                            player.getFoodData().setFoodLevel(0);
                            player.getInventory().clearContent();
                        }
                        livingTarget.setSecondsOnFire(3600);

                        // ========== 4. 伤害源 ==========
                        DamageSource divineSlaying = new DamageSource(world.registryAccess()
                                .registryOrThrow(Registries.DAMAGE_TYPE)
                                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                        new ResourceLocation("nuclear_industry", "divine_slaying"))));
                        DamageSource fusionExplosion = new DamageSource(world.registryAccess()
                                .registryOrThrow(Registries.DAMAGE_TYPE)
                                .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                        new ResourceLocation("nuclear_industry", "fusion_explosion"))));

                        // ========== 5. 辅助伤害 ==========
                        livingTarget.hurt(divineSlaying, livingTarget.getMaxHealth());
                        livingTarget.hurt(fusionExplosion, 88888888);

                        // ========== 6. 激进斩杀 ==========
                        if (aggressive) {
                            HealthOverrideHelper.forceSetHealth(livingTarget, 0.0f);
                            try {
                                Field healthField = LivingEntity.class.getDeclaredField("health");
                                healthField.setAccessible(true);
                                healthField.setFloat(livingTarget, 0.0f);
                            } catch (Exception ignored) {}
                            ReflectionHelper.zeroOutNumericFields(livingTarget);
                        } else {
                            livingTarget.setHealth(0);
                        }

                        // ========== 7. 死亡粒子 ==========
                        if (world instanceof ServerLevel sLevel) {
                            sLevel.sendParticles(ParticleTypes.POOF, livingTarget.getX(), livingTarget.getY() + 0.5, livingTarget.getZ(), 15, 0.5, 0.5, 0.5, 0.0);
                        }

                        // ========== 8. 触发死亡 ==========
                        livingTarget.die(divineSlaying);

                        // ========== 9. 抹杀模式 ==========
                        annihilateEntity(livingTarget, aggressive);

                        // ========== 10. 高频补刀 ==========
                        if (!world.isClientSide()) {
						    final boolean finalAggressive = aggressive;   // 复制为 final
						    NuclearIndustryMod.queueServerWork(1, () -> {
						        if (livingTarget.isAlive()) {
						            Runnable killTask = new Runnable() {
						                @Override
						                public void run() {
						                    if (livingTarget.isAlive()) {
						                        if (finalAggressive) {
						                            HealthOverrideHelper.forceSetHealth(livingTarget, 0.0f);
						                            try {
						                                Field healthField = LivingEntity.class.getDeclaredField("health");
						                                healthField.setAccessible(true);
						                                healthField.setFloat(livingTarget, 0.0f);
						                            } catch (Exception ignored) {}
						                            ReflectionHelper.zeroOutNumericFields(livingTarget);
						                        }
						                        livingTarget.hurt(divineSlaying, 20);
						                        if (livingTarget.isAlive()) {
						                            NuclearIndustryMod.queueServerWork(1, this);
						                        }
						                    }
						                }
						            };
						            killTask.run();
						        }
						    });
						}
                    }
                }

                // ========== 11. 物品冷却 ==========
                if (entity instanceof Player player) {
                    player.getCooldowns().addCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem(), 20);
                }
            }
        }
    }

    private static void clearEquipment(LivingEntity living) {
        // 脚
        if (living instanceof Player player) {
            player.getInventory().armor.set(0, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.FEET, new ItemStack(Blocks.AIR));
        }
        // 腿
        if (living instanceof Player player) {
            player.getInventory().armor.set(1, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Blocks.AIR));
        }
        // 胸
        if (living instanceof Player player) {
            player.getInventory().armor.set(2, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Blocks.AIR));
        }
        // 头
        if (living instanceof Player player) {
            player.getInventory().armor.set(3, new ItemStack(Blocks.AIR));
            player.getInventory().setChanged();
        } else {
            living.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Blocks.AIR));
        }
    }

    private static void annihilateEntity(Entity entity, boolean aggressive) {
        if (!(entity instanceof LivingEntity living)) return;

        if (aggressive) {
            HealthOverrideHelper.forceSetHealth(living, 0.0f);
            try {
                Field healthField = LivingEntity.class.getDeclaredField("health");
                healthField.setAccessible(true);
                healthField.setFloat(living, 0.0f);
            } catch (Exception ignored) {}
            ReflectionHelper.zeroOutNumericFields(living);
        } else {
            living.setHealth(0);
        }

        living.setPos(-9999, -9999, -9999);

        if (!(living instanceof Player)) {
            ListHelper.addEntityToRemoveList(living);
            living.discard();
            living.setInvisible(true);
            living.removeVehicle();
            living.remove(Entity.RemovalReason.DISCARDED);
            living.onRemovedFromWorld();
            living.setRemoved(Entity.RemovalReason.DISCARDED);
        }

        living.setHealth(0);
    }
}