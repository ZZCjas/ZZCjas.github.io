package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.explosion.nuclear.CraterGenerator;
import net.minecraftforge.registries.ForgeRegistries;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModBlocks;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandFunction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Optional;
import net.minecraft.core.BlockPos;
import org.lwjgl.opengl._3DFXTextureCompressionFXT1;

public class NukeStartProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("nuclear_industry:nuclearexplosion")), SoundSource.BLOCKS, 100, 1);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("nuclear_industry:nuclearexplosion")), SoundSource.BLOCKS, 100, 1, false);
			}
		world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
			CraterGenerator.generateCrater(
        _level,
        new BlockPos((int)x,(int)y,(int)z),
        NuclearIndustryModBlocks.RADIOACTIVE_MELT.get(),           // 弹坑内部填充方块
        NuclearIndustryModBlocks.BURNT_WOOD.get(),         // 焦黑原木
        NuclearIndustryModBlocks.BURNT_PLANK.get(),      // 焦黑木板
        NuclearIndustryModBlocks.BURNT_GRASS.get(),            // 烧焦草方块（可用 DIRT 代替）
        NuclearIndustryModBlocks.RADIOACTIVE_DIRT.get()      // 死土
    	);
		}
	}
}
