package net.zzcjas.nuclearindustry.procedures;

import net.zzcjas.nuclearindustry.explosion.nuclear.CraterGenerator;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModParticleTypes;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;
import net.zzcjas.nuclearindustry.init.NuclearIndustryModBlocks;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandFunction;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Optional;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraftforge.fml.ModList;

public class NukeStartProcedure {
    public static void execute(LevelAccessor world, double x, double y, double z) {
        if (world instanceof ServerLevel _level) {
        	_level.explode(null, x, y, z, 35, Level.ExplosionInteraction.TNT);
            if (!_level.isClientSide()) {
                _level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("nuclear_industry:nuclearexplosion")), SoundSource.BLOCKS, 100, 1);
            } else {
                _level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("nuclear_industry:nuclearexplosion")), SoundSource.BLOCKS, 100, 1, false);
            }
            world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
            CraterGenerator.generateCrater(
                _level,
                new BlockPos((int)x,(int)y,(int)z),
                NuclearIndustryModBlocks.RADIOACTIVE_MELT.get(),
                NuclearIndustryModBlocks.BURNT_WOOD.get(),
                NuclearIndustryModBlocks.BURNT_PLANK.get(),
                NuclearIndustryModBlocks.BURNT_GRASS.get(),
                NuclearIndustryModBlocks.RADIOACTIVE_DIRT.get()
            );

            // ========== 设置天气：下雨，2分钟后自动转晴 ==========
            _level.setWeatherParameters(0, 2400, true, false);

            // ========== 检测Mekanism模组并添加辐射 ==========
            if (ModList.get().isLoaded("mekanism")) {
                // 计算辐射覆盖区域的最大半径（基于CraterGenerator的常量推算）
                final int MAX_RAY_DISTANCE = 175; // 从CraterGenerator复制
                final float ZONE_4_RADIUS_MULTIPLIER = 1.75F;
                final double MAX_RADIUS = MAX_RAY_DISTANCE * ZONE_4_RADIUS_MULTIPLIER + 24.0; // 约330
                final int STEP = 90; // 步长，保证任何点至少被一个半径80的源覆盖（90/2 * sqrt(3) ≈ 77.94 < 80）

                // 生成网格点，确保覆盖以(x,y,z)为中心、半径为MAX_RADIUS的球体
                List<Vec3> radiationPoints = new ArrayList<>();
                int centerX = (int) Math.floor(x);
                int centerY = (int) Math.floor(y);
                int centerZ = (int) Math.floor(z);
                int maxIndex = (int) Math.ceil(MAX_RADIUS / STEP);
                for (int i = -maxIndex; i <= maxIndex; i++) {
                    for (int j = -maxIndex; j <= maxIndex; j++) {
                        for (int k = -maxIndex; k <= maxIndex; k++) {
                            double dx = i * STEP;
                            double dy = j * STEP;
                            double dz = k * STEP;
                            double distSq = dx * dx + dy * dy + dz * dz;
                            if (distSq <= MAX_RADIUS * MAX_RADIUS) {
                                radiationPoints.add(new Vec3(centerX + dx, centerY + dy, centerZ + dz));
                            }
                        }
                    }
                }

                // 在每个点执行辐射添加指令（每个源使用最大辐射值9999），并抑制命令输出
                String command = "mek radiation add 9999";
                for (Vec3 point : radiationPoints) {
                    CommandSourceStack silentSource = new CommandSourceStack(
                        CommandSource.NULL,
                        point,
                        Vec2.ZERO,
                        _level,
                        4,
                        "",
                        Component.literal(""),
                        _level.getServer(),
                        null
                    ).withSuppressedOutput();
                    _level.getServer().getCommands().performPrefixedCommand(silentSource, command);
                }
                System.out.println("[NUCLEAR_INDUSTRY] Added " + radiationPoints.size() + " Mekanism radiation sources.");
            } else {
                System.out.println("[NUCLEAR_INDUSTRY] Mekanism mod not loaded, skipping radiation.");
            }
        }
    }
}