package net.zzcjas.nuclearindustry.interfaces;

public interface IConstantRenderer {
    // Dummy interface to tell the client event handler to handle rendering rather than minecraft
}