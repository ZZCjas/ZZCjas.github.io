package net.zzcjas.nuclearindustry.mixin;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.zzcjas.nuclearindustry.util.IItemHandlerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = LivingEntity.class, priority = 0)
public abstract class LivingEntityMixin {

    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    @Shadow
    private static EntityDataAccessor<Float> DATA_HEALTH_ID;

    @Shadow
    public abstract float getMaxHealth();

    /**
     * 拦截 setHealth 调用，防止外部通过此方法减少血量。
     */
    @Inject(method = "setHealth", at = @At("HEAD"), cancellable = true)
    private void onSetHealth(float health, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            if (health < getMaxHealth()) {
                LOGGER.info("[NuclearIndustry] [Mixin] BLOCKED setHealth({}) for {} (current health: {})",
                        health, self.getName().getString(), self.getHealth());
                ci.cancel();
            } else {
                LOGGER.debug("[NuclearIndustry] [Mixin] Allowed setHealth({}) for {} (setting to max or above)",
                        health, self.getName().getString());
            }
        }
    }

    /**
     * 拦截 EntityData 同步更新事件，防止绕过 setHealth 直接修改血量数据字段。
     */
    @Inject(method = "onSyncedDataUpdated", at = @At("HEAD"), cancellable = true)
    private void onEntityDataSet(EntityDataAccessor<?> data, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (data == DATA_HEALTH_ID && IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.info("[NuclearIndustry] [Mixin] BLOCKED direct EntityData health modification for {}",
                    self.getName().getString());
            ci.cancel();
        }
    }

    /**
     * 修改 getHealth 返回值：若存在湮灭标记 → 返回 0；否则若持有粉碎机 → 显示满血。
     */
    @Inject(method = "getHealth", at = @At("RETURN"), cancellable = true)
    private void onGetHealth(CallbackInfoReturnable<Float> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        float original = cir.getReturnValue();

        // 优先判断湮灭标记
        if (self.getPersistentData().getBoolean("nuclearindustry:marked_for_divine_slaying")) {
            LOGGER.debug("[NuclearIndustry] [Mixin] getHealth() for {}: returning 0 due to divine slaying mark (original: {})",
                    self.getName().getString(), original);
            cir.setReturnValue(0.0F);
            return;
        }

        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            float fakeHealth = Math.max(getMaxHealth(), 20.0F);
            LOGGER.debug("[NuclearIndustry] [Mixin] getHealth() for {}: overriding {} -> {} (holding Matter Smasher)",
                    self.getName().getString(), original, fakeHealth);
            cir.setReturnValue(fakeHealth);
        }
    }

    /**
     * 拦截死亡逻辑，持有粉碎机的实体不会因任何伤害源而死亡。
     */
    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void onDie(DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.info("[NuclearIndustry] [Mixin] BLOCKED death for {} from source: {}",
                    self.getName().getString(), source.getMsgId());
            ci.cancel();
        }
    }

    /**
     * 拦截 isDeadOrDying 查询：
     * - 若存在湮灭标记，强制返回 true（表示实体已死亡）。
     * - 若持有粉碎机，强制返回 false（表示实体永远不会处于死亡状态）。
     */
    @Inject(method = "isDeadOrDying", at = @At("RETURN"), cancellable = true)
    private void onIsDeadOrDying(CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        boolean original = cir.getReturnValue();

        if (self.getPersistentData().getBoolean("nuclearindustry:marked_for_divine_slaying")) {
            LOGGER.debug("[NuclearIndustry] [Mixin] isDeadOrDying() for {}: overriding {} -> true (divine slaying mark)",
                    self.getName().getString(), original);
            cir.setReturnValue(true);
            return;
        }

        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.debug("[NuclearIndustry] [Mixin] isDeadOrDying() for {}: overriding {} -> false (holding Matter Smasher)",
                    self.getName().getString(), original);
            cir.setReturnValue(false);
        }
    }
}