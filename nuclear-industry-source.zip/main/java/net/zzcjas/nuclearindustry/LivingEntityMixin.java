package net.zzcjas.nuclearindustry.mixin;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.zzcjas.nuclearindustry.util.IItemHandlerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = LivingEntity.class, priority = 0)
public abstract class LivingEntityMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    @Shadow public abstract float getMaxHealth();

    @Inject(method = "setHealth", at = @At("HEAD"), cancellable = true)
    private void onSetHealth(float health, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            if (health != getMaxHealth()) {
                LOGGER.info("[NuclearIndustry] Blocked setHealth({}) for {}", health, self.getName().getString());
                ci.cancel();
            }
        }
    }

    @Inject(method = "getHealth", at = @At("RETURN"), cancellable = true)
    private void onGetHealth(CallbackInfoReturnable<Float> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            if (cir.getReturnValue() < getMaxHealth()) {
                cir.setReturnValue(getMaxHealth());
            }
        }
    }

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void onDie(DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.info("[NuclearIndustry] Blocked death for {} from source: {}", self.getName().getString(), source.getMsgId());
            ci.cancel();
        }
    }
}