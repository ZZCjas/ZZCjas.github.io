package net.zzcjas.nuclearindustry.mixin;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.zzcjas.nuclearindustry.util.IItemHandlerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = LivingEntity.class, priority = 0)
public abstract class LivingEntityMixin {

    private static final Logger LOGGER = LoggerFactory.getLogger("NuclearIndustry");

    @Shadow
    private static EntityDataAccessor<Float> DATA_HEALTH_ID;

    @Shadow
    public abstract float getMaxHealth();

    /**
     * 拦截 setHealth 调用。
     * 条件：持有神罚 且 新血量 < max(20, 最大生命值) → 取消
     */
    @Inject(method = "setHealth", at = @At("HEAD"), cancellable = true)
    private void onSetHealth(float health, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            float threshold = Math.max(20.0F, getMaxHealth());
            if (health < threshold) {
                LOGGER.info("[NuclearIndustry] Blocked setHealth({}) for {} (threshold={})",
                        health, self.getName().getString(), threshold);
                ci.cancel();
            } else {
                LOGGER.debug("[NuclearIndustry] Allowed setHealth({}) for {}",
                        health, self.getName().getString());
            }
        }
    }

    /**
     * 拦截 EntityData 同步更新（防止直接修改 DATA_HEALTH_ID 后调用 setHealth）。
     * 条件：持有神罚 且 新血量 < max(20, 最大生命值) → 取消
     */
    @Inject(method = "onSyncedDataUpdated", at = @At("HEAD"), cancellable = true)
    private void onEntityDataSet(EntityDataAccessor<?> data, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (data == DATA_HEALTH_ID && IItemHandlerHelper.hasMatterSmasher(self)) {
            float newHealth = self.getEntityData().get(DATA_HEALTH_ID);
            float threshold = Math.max(20.0F, getMaxHealth());
            if (newHealth < threshold) {
                LOGGER.info("[NuclearIndustry] Blocked EntityData health update to {} for {} (threshold={})",
                        newHealth, self.getName().getString(), threshold);
                ci.cancel();
            } else {
                LOGGER.debug("[NuclearIndustry] Allowed EntityData health update to {} for {}",
                        newHealth, self.getName().getString());
            }
        }
    }

    /**
     * 修改 getHealth 返回值：若存在湮灭标记 → 返回 0；否则若持有粉碎机 → 显示满血（≥20 且 ≥最大生命值）。
     */
    @Inject(method = "getHealth", at = @At("RETURN"), cancellable = true)
    private void onGetHealth(CallbackInfoReturnable<Float> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        float original = cir.getReturnValue();

        if (self.getPersistentData().getBoolean("nuclearindustry:marked_for_divine_slaying")) {
            LOGGER.debug("[NuclearIndustry] getHealth() for {}: returning 0 (divine slaying mark)", self.getName().getString());
            cir.setReturnValue(0.0F);
            return;
        }

        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            float fakeHealth = Math.max(getMaxHealth(), 20.0F);
            LOGGER.debug("[NuclearIndustry] getHealth() for {}: override {} -> {}", self.getName().getString(), original, fakeHealth);
            cir.setReturnValue(fakeHealth);
        }
    }

    /**
     * 拦截死亡逻辑：持有神罚的实体不会因任何伤害源而死亡。
     */
    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void onDie(DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.info("[NuclearIndustry] Blocked death for {} from source: {}", self.getName().getString(), source.getMsgId());
            ci.cancel();
        }
    }

    /**
     * 拦截 isDeadOrDying 查询：
     * - 若存在湮灭标记，强制返回 true。
     * - 若持有粉碎机，强制返回 false。
     */
    @Inject(method = "isDeadOrDying", at = @At("RETURN"), cancellable = true)
    private void onIsDeadOrDying(CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        boolean original = cir.getReturnValue();

        if (self.getPersistentData().getBoolean("nuclearindustry:marked_for_divine_slaying")) {
            LOGGER.debug("[NuclearIndustry] isDeadOrDying() for {}: override {} -> true", self.getName().getString(), original);
            cir.setReturnValue(true);
            return;
        }

        if (IItemHandlerHelper.hasMatterSmasher(self)) {
            LOGGER.debug("[NuclearIndustry] isDeadOrDying() for {}: override {} -> false", self.getName().getString(), original);
            cir.setReturnValue(false);
        }
    }
}