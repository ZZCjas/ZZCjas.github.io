EA32系列图纸

EA32系列为指数航天Exponent Aerospace研发的总冲200Ns~300Ns级32mm内径36mm外径的制式微型可复用金属发动机系列
包含EA32L,EA32-RAP,EA32-C

EA32L适用于圆孔装药KNSB
由 加长外壳.step,喷管.step,堵头.step 组成

EA32-RAP适用于各类AP基燃料
由 外壳.step,喷管.step,堵头.step 组成

EA32-C适用于C孔装药KNSB
由 加长外壳.step,C孔暴力喷管.step,堵头.step 组成

注:EA32-C是喷燃比500~600+的暴力高压机，请谨慎使用

整个发动机的所有加工了密封槽的部分都要安装全新的未老化的32*2.5mm O型密封圈(推荐使用耐高温绿色氟胶圈)，具体密封布局若有不清楚的可通过邮件联系我们

©2025 指数航天 版权所有

有技术性问题可发邮件询问:
电子邮箱地址2772194090@qq.com

最新版图纸链接:
https://zzcjas.github.io/EA32.zip

免责声明

指数航天（Exponent Aerospace）提供的EA32系列发动机设计文件（包括但不限于STEP模型）仅供教育、研究及学术参考之目的。使用者必须具备相应的专业知识和技能，并完全理解固体火箭发动机实验所固有的极高风险，包括但不限于导致财产损失、人身伤害甚至死亡。

禁止填装除以上提到的任何其他数据未知的推进剂,禁止填装密度过小或工艺不达标的推进剂(如粉压燃料)

使用者自愿选择下载、使用或修改此设计文件，并须对由此产生的一切后果承担全部责任。设计者、版权所有者及文件提供者对任何直接、间接、特殊或后果性的损失或损害概不负责，无论其成因如何。

严禁将此设计用于任何非法、危险或商业用途。任何基于此设计的制造、测试或操作行为均被视为使用者自行承担风险的独立决定。继续使用即表示您已阅读、理解并无条件同意接受本免责声明的全部条款。

EA32 Series Drawings

The EA32 series is a standardized miniature reusable metal engine family developed by Exponent Aerospace, with a total impulse range of 200 Ns to 300 Ns, an inner diameter of 32 mm, and an outer diameter of 36 mm.
It includes the EA32L, EA32-RAP, and EA32-C models.

The EA32L is designed for BATES grains using KNSB propellant.
It consists of the following components:

Extended Casing.step

Nozzle.step

End Cap.step

The EA32-RAP is suitable for various AP-based fuels.
It consists of the following components:

Casing.step

Nozzle.step

End Cap.step

The EA32-C is optimized for C-slot grains using KNSB propellant.
It consists of the following components:

Extended Casing.step

C-slot High-Performance Nozzle.step

End Cap.step

Note: The EA32-C is a high-performance, high-pressure engine with a port-to-throat ratio of 500–600+, and must be operated with extreme caution.

All machined sealing grooves on the motor must be equipped with new, non-aged 32×2.5 mm O-rings (high-temperature resistant green fluoropolymer O-rings are recommended). For further details regarding the specific sealing arrangement, please contact us via email if any clarification is needed.

©2025 Exponent Aerospace. All rights reserved.

For technical inquiries, please contact:
Email: 2772194090@qq.com

Link to the latest version of the drawings:
https://zzcjas.github.io/EA32.zip

Disclaimer

The EA32 series engine design files (including but not limited to STEP models) provided by Exponent Aerospace are intended solely for educational, research, and academic reference purposes. Users must possess relevant professional knowledge and skills and fully understand the inherent high risks associated with solid rocket motor experimentation, including but not limited to property damage, personal injury, or even death.

Do not load any propellants other than those mentioned above with unknown performance data. The use of propellants with insufficient density or substandard manufacturing processes (such as loosely packed or powder-compacted propellants) is strictly prohibited.

Users voluntarily choose to download, use, or modify these design files and assume full responsibility for all consequences arising therefrom. The designers, copyright owners, and providers of the files shall not be held liable for any direct, indirect, special, or consequential losses or damages, regardless of cause.

The use of this design for any illegal, hazardous, or commercial purposes is strictly prohibited. Any manufacturing, testing, or operational activities based on this design are considered independent decisions made at the user’s own risk. By proceeding with use, you acknowledge that you have read, understood, and unconditionally agreed to all terms of this disclaimer.