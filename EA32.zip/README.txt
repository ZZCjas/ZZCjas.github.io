EA32系列图纸

EA32系列为指数航天Exponent Aerospace研发的总冲200Ns~300Ns级32mm内径36mm外径的制式微型可复用金属发动机系列
包含EA32L,EA32-RAP,EA32-C

EA32L适用于圆孔装药KNSB
由 加长外壳.step,喷管.step,堵头.step 组成
使用EA32L时,应当使用两段100mm长的KNSB的圆孔药柱,内孔直径8~10mm,隔热层应当使用外径32mm厚1.3~2mm的PVC或PPR管材。两段药柱之间,药柱与喷管堵头之间以及药柱与药柱之间的空隙都应当放入32*2.5mmO型氟胶密封圈,固定方式是两端各拧入8枚m5螺栓,螺栓强度要求至少10.9级

EA32-RAP适用于各类AP基燃料
由 外壳.step,喷管.step,堵头.step 组成
使用EA32-RAP时,应当使用两段74mm长的APCP或RAP的圆孔药柱,内孔直径8~10mm,隔热层应当使用外径32mm厚2mm的PVC或PPR管材。药柱与喷管堵头之间以及药柱与药柱之间的空隙都都应当放入32*2.5mmO型氟胶密封圈,固定方式是两端各卡入一个卡簧，规格为32mm内卡。

EA32-C适用于C孔装药KNSB
由 加长外壳.step,C孔暴力喷管.step,堵头.step 组成
使用EA32-C时,应当使用一段200mm长的工艺优秀的KNSB的C孔药柱,药柱开槽宽度5mm,开槽深度16mm,隔热层应当使用外径32mm厚2mm的PVC或PPR管材。药柱与喷管堵头之间都应当放入32*2.5mmO型氟胶密封圈,固定方式是两端各拧入8枚m5螺栓,螺栓强度要求至少12.9级

注:EA32-C是喷燃比500~600+的暴力高压机，请谨慎使用,在加工EA32L和EA32-RAP时要将喷管堵头的外径额外削掉0.1mm以便装配。

所有EA32系列的发动机外壳必须使用6061-T6铝合金制造,喷管堵头必须使用耐高温耐烧蚀材料(如酚醛,45#钢,304不锈钢等)

整个发动机的所有加工了密封槽的部分都要安装全新的未老化的32*2.8mm O型密封圈(推荐使用耐高温绿色氟胶圈)

©2025 指数航天 版权所有

有技术性问题可发邮件询问:
电子邮箱地址2772194090@qq.com

最新版图纸链接:
https://zzcjas.github.io/EA32.zip

免责声明

指数航天（Exponent Aerospace）提供的EA32系列发动机设计文件仅供教育、研究、学术参考及加工之目的。使用者必须具备相应的专业知识和技能，并完全理解固体火箭发动机实验所固有的极高风险，包括但不限于导致财产损失、信誉损失、人身伤害甚至死亡。

禁止填装除以上提到的任何其他数据未知或燃速过高的推进剂,禁止填装密度过小或工艺不达标的推进剂(如粉压燃料)

使用者自愿选择下载、使用或修改此设计文件，并须对由此产生的一切后果承担全部责任。设计者、版权所有者及文件提供者对任何直接、间接、特殊或后果性的损失或损害概不负责，无论其成因如何。

严禁将此设计用于任何非法、危险或商业用途。任何基于此设计的制造、测试或操作行为均被视为使用者自行承担风险的独立决定。继续使用即表示您已阅读、理解并无条件同意接受本免责声明的全部条款。



EA32 Series Drawings

The EA32 series is a standardized micro reusable metal engine series developed by Exponent Aerospace, featuring a total impulse of 200 Ns to 300 Ns, with a 32mm inner diameter and a 36mm outer diameter.
It includes the EA32L, EA32-RAP, and EA32-C.

EA32L is suitable for KNSB with circular perforation.
It consists of: Elongated_Casing.step, Nozzle.step, Bulkhead.step.
When using the EA32L, two 100mm-long KNSB BATES grains with 8-10mm inner diameter should be used. The thermal insulation layer should be a PVC or PPR tube with a 32mm outer diameter and 1.3-2mm wall thickness. A 32*2.5mm fluororubber (FKM) O-ring should be placed between the two grain segments, and between the grains and the nozzle/bulkhead. The assembly is secured by fastening 8x M5 bolts at each end; the bolts must have a minimum strength grade of 10.9.

EA32-RAP is suitable for various AP-based propellants.
It consists of: Casing.step, Nozzle.step, Bulkhead.step.
When using the EA32-RAP, two 74mm-long APCP or RAP BATES grains with 8-10mm inner diameter should be used. The thermal insulation layer should be a PVC or PPR tube with a 32mm outer diameter and 2mm wall thickness. A 32*2.5mm fluororubber (FKM) O-ring should be placed between the two grain segments, and between the grains and the nozzle/bulkhead. The assembly is secured by installing a snap ring (32mm internal circlip) at each end.

EA32-C is suitable for KNSB with C-slot perforation.
It consists of: Elongated_Casing.step, C-Slot_High-Performance_Nozzle.step, Bulkhead.step.
When using the EA32-C, a single 200mm-long, high-quality, well-manufactured KNSB grain with a C-slot perforation should be used. The slot width is 5mm, and the slot depth is 16mm. The thermal insulation layer should be a PVC or PPR tube with a 32mm outer diameter and 2mm wall thickness. A 32*2.5mm fluororubber (FKM) O-ring should be placed between the grain and the nozzle/bulkhead. The assembly is secured by fastening 8x M5 bolts at each end; the bolts must have a minimum strength grade of 12.9.

Note: The EA32-C is a high-pressure engine with extreme performance (port-to-throat ratio of 500-600+). Use with extreme caution.

All EA32 series engine casings must be manufactured from 6061-T6 aluminum alloy. Nozzles and bulkheads must be made from high-temperature, ablation-resistant materials (e.g., phenolic resin, 45# steel, 304 stainless steel).

New, non-aged 32*2.5mm O-rings (high-temperature green fluororubber (FKM) O-rings are recommended) must be installed in all machined sealing grooves throughout the entire engine.

© 2025 Exponent Aerospace. All rights reserved.

For technical inquiries, please email:
Email: 2772194090@qq.com

Link to the latest version of the drawings:
https://zzcjas.github.io/EA32.zip

Disclaimer

The EA32 series engine design files (including but not limited to STEP models) provided by Exponent Aerospace are intended solely for educational, research, academic reference, and manufacturing purposes. Users must possess the requisite professional knowledge and skills and fully understand the inherently extreme risks associated with solid rocket motor experimentation, including, but not limited to, property damage, loss of reputation, personal injury, or even death.

It is prohibited to load any propellants other than those mentioned above with unknown characteristics or excessively high burn rates. It is prohibited to load propellants with insufficient density or that fail to meet manufacturing quality standards (e.g., powder-pressed fuels).

Users voluntarily choose to download, use, or modify these design files and must assume full responsibility for all consequences arising therefrom. The designers, copyright owners, and providers of these files shall not be held liable for any direct, indirect, special, or consequential losses or damages, regardless of their cause.

The use of this design for any illegal, hazardous, or commercial purposes is strictly prohibited. Any manufacturing, testing, or operation based on this design is considered an independent decision made at the user's own risk. Proceeding with use indicates that you have read, understood, and unconditionally agreed to accept all terms of this disclaimer in their entirety.